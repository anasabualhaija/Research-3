// Grabber.ino///////////////ANAs
// ===========

#include <WiFi.h>
#include <esp_now.h>

// === ESP-NOW MACs & Message Definition ===
uint8_t grabberMAC[6] = { 0xD0, 0xEF, 0x76, 0x58, 0x14, 0xB0 };
uint8_t hbwMAC    [6] = { 0xCC, 0x7B, 0x5C, 0xFD, 0x37, 0xE4 };

volatile bool putOvenPending = false;

#define MSG_PIECE_READY   1
#define MSG_PIECE_PICKED 2
#define Bring_the_holder 3

typedef struct {
  uint8_t cmd;
  uint8_t slotIndex;
} message_t;

// === Position Definitions ===
struct Position {
  const char* name;
  int rotate;
  int horizontal;
  int vertical;
};

const Position positions[] = {
  {"Blue_from_the_color_station", -1220, -2150, -4800},
  {"Red_from_the_color_station",  -1480, -1600, -4800},
  {"White_from_the_color_station",-1800, -1400, -4800},
  {"Oven",                        -3540, -3380, -3000},
  {"HBW",                         -5380,  -680, -1000}
};
const int NUM_NAMED_POSITIONS = sizeof(positions) / sizeof(Position);
String currentPosition = "origin";

// === Forward Declarations ===
void pickAtPosition(const Position &pos);
void putAtPosition(const Position &pos);

// ESP-NOW callbacks and initializer
void onDataSent(const uint8_t *mac_addr, esp_now_send_status_t status);
void onDataRecv(const esp_now_recv_info_t *info, const uint8_t *data, int len);
void initEspNow(const uint8_t* peerMAC);

void onDataSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {
  // info->des_addr points to destination MAC, info->src_addr is our MAC, etc.
  // optionally check 'status' (ESP_NOW_SEND_SUCCESS / ESP_NOW_SEND_FAIL)
}

void onDataRecv(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  if (len < sizeof(message_t)) return;
  message_t msg;
  memcpy(&msg, data, sizeof(msg));
  if (msg.cmd == MSG_PIECE_READY) {

   // Serial.println("anas2");
    // A) Pick from HBW (blocking, but quick)
    pickAtPosition(positions[4]);  // HBW index

    // B) Immediately notify HBW it can store
    message_t reply = { MSG_PIECE_PICKED, msg.slotIndex };
    esp_now_send(hbwMAC, (uint8_t*)&reply, sizeof(reply));

    // C) Defer the oven‐put to loop()
    putOvenPending = true;

    // D) Return right away—no oven move here!
    return;
  }
}
void initEspNow(const uint8_t* peerMAC) {
  WiFi.mode(WIFI_STA);
  if (esp_now_init() != ESP_OK) {
   // Serial.println("ESP-NOW init failed");
    return;
  }
  esp_now_register_send_cb(onDataSent);
  esp_now_register_recv_cb(onDataRecv);

  esp_now_peer_info_t peer = {};
  memcpy(peer.peer_addr, peerMAC, 6);
  peer.channel = 0;
  peer.encrypt = false;
  if (esp_now_add_peer(&peer) != ESP_OK) {
   // Serial.println("Failed to add peer");
  }
}

// === Pin Definitions ===
// Reference Switches
#define REF_SWITCH_VERTICAL_AXIS       36
#define REF_SWITCH_HORIZONTAL_AXIS     39
#define REF_SWITCH_ROTATE              34
// Encoders
#define ENC_VERT_AXIS_IMPULSE_1        35
#define ENC_VERT_AXIS_IMPULSE_2        32
#define ENC_HORZ_AXIS_IMPULSE_1        33
#define ENC_HORZ_AXIS_IMPULSE_2        25
#define ENC_ROTATE_IMPULSE_1           26
#define ENC_ROTATE_IMPULSE_2           27
// Motors & Vacuum
#define MOTOR_VERT_AXIS_UP             16
#define MOTOR_VERT_AXIS_DOWN           17
#define MOTOR_HORZ_AXIS_BACKWARD       4
#define MOTOR_HORZ_AXIS_FORWARD        18
#define MOTOR_ROTATE_CLOCKWISE         19
#define MOTOR_ROTATE_COUNTERCLOCKWISE  21
#define COMPRESSOR                     22
#define VALVE_VACUUM                   23

// === Globals & Encoder Table ===
volatile int verticalPulseCount   = 0;
volatile int horizontalPulseCount = 0;
volatile int rotatePulseCount     = 0;

volatile int8_t verticalMoveDirection   = 0;
volatile int8_t horizontalMoveDirection = 0;
volatile int8_t rotateMoveDirection     = 0;

const int8_t encoder_table[16] = {
   0, -1,  1,  0,
   1,  0,  0, -1,
  -1,  0,  0,  1,
   0,  1, -1,  0
};

// === Encoder ISRs ===
void IRAM_ATTR handleVerticalEncoder() {
  if (verticalMoveDirection == 1) verticalPulseCount++;
  else if (verticalMoveDirection == -1) verticalPulseCount--;
}

void IRAM_ATTR handleRotateEncoder() {
  static uint8_t lastState = 0;
  if (rotateMoveDirection == 0) return;
  uint8_t A = digitalRead(ENC_ROTATE_IMPULSE_1);
  uint8_t B = digitalRead(ENC_ROTATE_IMPULSE_2);
  uint8_t cur = (A<<1)|B;
  uint8_t comb = (lastState<<2)|cur;
  rotatePulseCount += encoder_table[comb];
  lastState = cur;
}

void IRAM_ATTR handleHorizontalEncoder() {
  static uint8_t lastState = 0;
  if (horizontalMoveDirection == 0) return;
  uint8_t A = digitalRead(ENC_HORZ_AXIS_IMPULSE_1);
  uint8_t B = digitalRead(ENC_HORZ_AXIS_IMPULSE_2);
  uint8_t cur = (A<<1)|B;
  uint8_t comb = (lastState<<2)|cur;
  horizontalPulseCount -= encoder_table[comb];
  lastState = cur;
}

// === Movement Routines ===
void moveVerticalToPosition(int target) {
  if (verticalPulseCount < target) {
    digitalWrite(MOTOR_VERT_AXIS_UP, HIGH);
    digitalWrite(MOTOR_VERT_AXIS_DOWN, LOW);
    verticalMoveDirection = 1;
  } else if (verticalPulseCount > target) {
    digitalWrite(MOTOR_VERT_AXIS_UP, LOW);
    digitalWrite(MOTOR_VERT_AXIS_DOWN, HIGH);
    verticalMoveDirection = -1;
  } else return;
  while ((verticalMoveDirection==1  && verticalPulseCount<target) ||
         (verticalMoveDirection==-1 && verticalPulseCount>target)) {
    delay(1);
  }
  digitalWrite(MOTOR_VERT_AXIS_UP, LOW);
  digitalWrite(MOTOR_VERT_AXIS_DOWN, LOW);
  verticalMoveDirection = 0;
}

void moveRotateToPosition(int target) {
  int overshoot = -15;
  if (rotatePulseCount < target) {
    rotateMoveDirection = 1;
    digitalWrite(MOTOR_ROTATE_CLOCKWISE, HIGH);
    digitalWrite(MOTOR_ROTATE_COUNTERCLOCKWISE, LOW);
    while (rotatePulseCount < target + overshoot) delay(1);
    digitalWrite(MOTOR_ROTATE_CLOCKWISE, LOW);
    rotatePulseCount = target;
  } else if (rotatePulseCount > target) {
    rotateMoveDirection = -1;
    digitalWrite(MOTOR_ROTATE_CLOCKWISE, LOW);
    digitalWrite(MOTOR_ROTATE_COUNTERCLOCKWISE, HIGH);
    while (rotatePulseCount > target) delay(1);
    digitalWrite(MOTOR_ROTATE_COUNTERCLOCKWISE, LOW);
  }
  rotateMoveDirection = 0;
}

void moveHorizontalToPosition(int target) {
  if (horizontalPulseCount < target) {
    horizontalMoveDirection = 1;
    digitalWrite(MOTOR_HORZ_AXIS_BACKWARD, HIGH);
    digitalWrite(MOTOR_HORZ_AXIS_FORWARD,  LOW);
    while (horizontalPulseCount < target) delay(1);
    digitalWrite(MOTOR_HORZ_AXIS_BACKWARD, LOW);
  } else if (horizontalPulseCount > target) {
    horizontalMoveDirection = -1;
    digitalWrite(MOTOR_HORZ_AXIS_BACKWARD, LOW);
    digitalWrite(MOTOR_HORZ_AXIS_FORWARD,  HIGH);
    while (horizontalPulseCount > target) delay(1);
    digitalWrite(MOTOR_HORZ_AXIS_FORWARD,  LOW);
  }
  horizontalMoveDirection = 0;
}

// === Homing Routines ===
void homeVerticalAxis() {

 if (digitalRead(REF_SWITCH_VERTICAL_AXIS)==LOW){  
  digitalWrite(MOTOR_VERT_AXIS_UP, HIGH);
  int c = 0;
  while (c < 10) {
    if (digitalRead(REF_SWITCH_VERTICAL_AXIS)==HIGH) c++;
    else c = 0;
    delay(1);
  }
  digitalWrite(MOTOR_VERT_AXIS_UP, LOW);
  verticalPulseCount = 0; verticalMoveDirection = 0;
}}

void homeRotateAxis() {

  if (digitalRead(REF_SWITCH_ROTATE)==LOW){

  digitalWrite(MOTOR_ROTATE_CLOCKWISE, HIGH);
  rotateMoveDirection = 1;
  int c = 0;
  while (c < 10) {
    if (digitalRead(REF_SWITCH_ROTATE)==HIGH) c++;
    else c = 0;
    delay(1);
  }
  digitalWrite(MOTOR_ROTATE_CLOCKWISE, LOW);
  rotatePulseCount = 0; rotateMoveDirection = 0;
}}

void homeHorizontalAxis() {
  if (digitalRead(REF_SWITCH_HORIZONTAL_AXIS)==LOW){

  digitalWrite(MOTOR_HORZ_AXIS_BACKWARD, HIGH);
  horizontalMoveDirection = 1;
  int c = 0;
  while (c < 10) {
    if (digitalRead(REF_SWITCH_HORIZONTAL_AXIS)==HIGH) c++;
    else c = 0;
    delay(1);
  }
  digitalWrite(MOTOR_HORZ_AXIS_BACKWARD, LOW);
  horizontalPulseCount = 0; horizontalMoveDirection = 0;
}}

// === FreeRTOS Tasks ===
void pulseCounterTask(void *pvParameters) {
  while (1) delay(100);
}

void motionTask(void *pvParameters) {
  delay(1000);
  homeVerticalAxis();
  homeHorizontalAxis();
  homeRotateAxis();
  currentPosition = "origin";
  for (int i = 0; i < NUM_NAMED_POSITIONS; i++) {
   // Serial.println(positions[i].name);
  }
  vTaskDelete(NULL);
}

// === Pick & Put Routines ===
void pickAtPosition(const Position &pos) {
  if (String(pos.name) == "HBW") {
    homeVerticalAxis();
    homeHorizontalAxis();
    moveRotateToPosition(pos.rotate);
    moveHorizontalToPosition(pos.horizontal);
    moveVerticalToPosition(pos.vertical);
    digitalWrite(COMPRESSOR, HIGH);
    digitalWrite(VALVE_VACUUM, HIGH);
    delay(100);
    homeVerticalAxis();
    homeHorizontalAxis();
  } else {
    moveRotateToPosition(pos.rotate);
    moveHorizontalToPosition(pos.horizontal);
    moveVerticalToPosition(pos.vertical);
    digitalWrite(COMPRESSOR, HIGH);
    digitalWrite(VALVE_VACUUM, HIGH);
    delay(100);
  }
  currentPosition = pos.name;
}

void putAtPosition(const Position &pos) {
  // static counter to track how many times we've put into the Oven
  static int ovenPutCount = 0;
  bool isOven = (String(pos.name) == "Oven");
  
  // ——— existing move & drop logic ———
  if (String(pos.name) == "HBW") {
    homeVerticalAxis();
    homeHorizontalAxis();
  }
  if (isOven && currentPosition == "HBW") {
    moveRotateToPosition(pos.rotate);
    moveHorizontalToPosition(pos.horizontal);
    moveVerticalToPosition(pos.vertical);
  } else {
    homeVerticalAxis();
    homeHorizontalAxis();
    moveRotateToPosition(pos.rotate);
    moveHorizontalToPosition(pos.horizontal);
    moveVerticalToPosition(pos.vertical);
    
    
    
    
  }
  digitalWrite(COMPRESSOR, LOW);
  digitalWrite(VALVE_VACUUM, LOW);
  delay(100);
  if (isOven) {
    moveVerticalToPosition(-1500);
    moveHorizontalToPosition(-1000);
  }
  if (String(pos.name) == "HBW") {
    homeVerticalAxis();
    homeHorizontalAxis();
  }
  currentPosition = pos.name;
  // ——— end existing logic ———

  // if this was a put-to-Oven, bump the counter
  if (isOven) {
    ovenPutCount++;
    // every 3rd Oven‐put: go home (reference point) and reset counter
    if (ovenPutCount == 3 || ovenPutCount ==6 || ovenPutCount== 9) {
      // full homing sequence back to “origin”
      homeVerticalAxis();
      homeHorizontalAxis();
      homeRotateAxis();
      currentPosition = "origin";

      if(ovenPutCount == 1){
      ovenPutCount = 0;

      //FromColorStationToHBW();
      }
    }
  }
}

void FromColorStationToHBW(){

  message_t msg;
  
pickAtPosition(positions[0]);

message_t reply = { Bring_the_holder, msg.slotIndex };
esp_now_send(hbwMAC, (uint8_t*)&reply, sizeof(reply));

putAtPosition(positions[4]);

}
// === setup() & loop() ===
void setup() {
  Serial.begin(115200);
  delay(500);

  // Initialize ESP-NOW link to HBW
  initEspNow(hbwMAC);

  // Pin modes & initial states
  pinMode(REF_SWITCH_VERTICAL_AXIS,   INPUT_PULLUP);
  pinMode(REF_SWITCH_HORIZONTAL_AXIS, INPUT_PULLUP);
  pinMode(REF_SWITCH_ROTATE,          INPUT_PULLUP);

  pinMode(ENC_VERT_AXIS_IMPULSE_1, INPUT);
  pinMode(ENC_VERT_AXIS_IMPULSE_2, INPUT);
  pinMode(ENC_HORZ_AXIS_IMPULSE_1, INPUT);
  pinMode(ENC_HORZ_AXIS_IMPULSE_2, INPUT);
  pinMode(ENC_ROTATE_IMPULSE_1,    INPUT);
  pinMode(ENC_ROTATE_IMPULSE_2,    INPUT);

  pinMode(MOTOR_VERT_AXIS_UP,              OUTPUT);
  pinMode(MOTOR_VERT_AXIS_DOWN,            OUTPUT);
  pinMode(MOTOR_HORZ_AXIS_BACKWARD,        OUTPUT);
  pinMode(MOTOR_HORZ_AXIS_FORWARD,         OUTPUT);
  pinMode(MOTOR_ROTATE_CLOCKWISE,           OUTPUT);
  pinMode(MOTOR_ROTATE_COUNTERCLOCKWISE,   OUTPUT);
  pinMode(COMPRESSOR,                       OUTPUT);
  pinMode(VALVE_VACUUM,                     OUTPUT);

  digitalWrite(MOTOR_VERT_AXIS_UP,            LOW);
  digitalWrite(MOTOR_VERT_AXIS_DOWN,          LOW);
  digitalWrite(MOTOR_HORZ_AXIS_BACKWARD,      LOW);
  digitalWrite(MOTOR_HORZ_AXIS_FORWARD,       LOW);
  digitalWrite(MOTOR_ROTATE_CLOCKWISE,        LOW);
  digitalWrite(MOTOR_ROTATE_COUNTERCLOCKWISE, LOW);
  digitalWrite(COMPRESSOR,                    LOW);
  digitalWrite(VALVE_VACUUM,                  LOW);

  attachInterrupt(digitalPinToInterrupt(ENC_VERT_AXIS_IMPULSE_1), handleVerticalEncoder,   CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_VERT_AXIS_IMPULSE_2), handleVerticalEncoder,   CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_ROTATE_IMPULSE_1),    handleRotateEncoder,     CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_ROTATE_IMPULSE_2),    handleRotateEncoder,     CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_HORZ_AXIS_IMPULSE_1), handleHorizontalEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_HORZ_AXIS_IMPULSE_2), handleHorizontalEncoder, CHANGE);

  xTaskCreatePinnedToCore(pulseCounterTask, "PulseCounterTask", 1000, NULL, 1, NULL, 0);
  xTaskCreatePinnedToCore(motionTask,       "MotionTask",       3000, NULL, 1, NULL, 1);
  xTaskCreatePinnedToCore(serialLoggerTask, "SerialLogger", 3000, NULL, 1, NULL, 1);

}

void serialLoggerTask(void *pvParameters) {
  Serial.println(
    "timestamp(ms),REF_SWITCH_VERTICAL_AXIS,REF_SWITCH_HORIZONTAL_AXIS,REF_SWITCH_ROTATE,"
    "MOTOR_VERT_AXIS_UP,MOTOR_VERT_AXIS_DOWN,MOTOR_HORZ_AXIS_BACKWARD,MOTOR_HORZ_AXIS_FORWARD,"
    "MOTOR_ROTATE_CLOCKWISE,MOTOR_ROTATE_COUNTERCLOCKWISE,COMPRESSOR,VALVE_VACUUM"
  );

  while (true) {
    unsigned long ts = millis();
    Serial.print(ts);

    Serial.print(",");
    Serial.print(digitalRead(REF_SWITCH_VERTICAL_AXIS));
    Serial.print(",");
    Serial.print(digitalRead(REF_SWITCH_HORIZONTAL_AXIS));
    Serial.print(",");
    Serial.print(digitalRead(REF_SWITCH_ROTATE));

    Serial.print(",");
    Serial.print(digitalRead(MOTOR_VERT_AXIS_UP));
    Serial.print(",");
    Serial.print(digitalRead(MOTOR_VERT_AXIS_DOWN));
    Serial.print(",");
    Serial.print(digitalRead(MOTOR_HORZ_AXIS_BACKWARD));
    Serial.print(",");
    Serial.print(digitalRead(MOTOR_HORZ_AXIS_FORWARD));
    Serial.print(",");
    Serial.print(digitalRead(MOTOR_ROTATE_CLOCKWISE));
    Serial.print(",");
    Serial.print(digitalRead(MOTOR_ROTATE_COUNTERCLOCKWISE));
    Serial.print(",");
    Serial.print(digitalRead(COMPRESSOR));
    Serial.print(",");
    Serial.println(digitalRead(VALVE_VACUUM));

    vTaskDelay(pdMS_TO_TICKS(20));
  }
}


void loop() {

    if (putOvenPending) {
    putOvenPending = false;
    putAtPosition(positions[3]);  // Oven index
  }


  if (Serial.available()) {
    String input = Serial.readStringUntil('\n');
    input.trim();

    bool isPick = input.startsWith("pick ");
    bool isPut  = input.startsWith("put ");

    if (isPick || isPut) {
      String targetName = input.substring(isPick ? 5 : 4);
      targetName.trim();
      for (int i = 0; i < NUM_NAMED_POSITIONS; i++) {
        if (targetName.equalsIgnoreCase(positions[i].name)) {
          if (isPick) {
            pickAtPosition(positions[i]);
            // auto‐put logic
            if (String(positions[i].name) == "HBW")
              putAtPosition(positions[3]);  // Oven
            else
              putAtPosition(positions[4]);  // HBW
          } else {
            putAtPosition(positions[i]);
          }
          return;
        }
      }
     // Serial.println("Unknown position name. Try again.");
      return;
    }

    // Direct named‐position move
    for (int i = 0; i < NUM_NAMED_POSITIONS; i++) {
      if (input.equalsIgnoreCase(positions[i].name)) {
        if (currentPosition == "HBW" && String(positions[i].name) == "Oven") {
          moveRotateToPosition(positions[i].rotate);
          moveHorizontalToPosition(positions[i].horizontal);
          moveVerticalToPosition(positions[i].vertical);
        }
        currentPosition = positions[i].name;
        return;
      }
    }

   // Serial.println("Unknown command or position. Try again.");
  }
}
