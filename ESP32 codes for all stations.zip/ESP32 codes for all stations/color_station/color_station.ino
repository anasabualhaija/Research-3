// ============================================================================
// ESP32 Color Sorter with Latched-Low Queue Sensors (Q1, Q2, Q3)
// Sorting decision is based on the MIN voltage seen for the whole piece
// ============================================================================

/* =====================
 *  Forward Declarations
 * ===================== */
void serialLoggerTask(void *pvParameters);

/* ================
 *  Pin Definitions
 * ================ */
#define BELT_MOTOR     13
#define COMPRESSOR     12
#define VALVE_WHITE    14
#define VALVE_RED      27
#define VALVE_BLUE     26

#define PULSE_COUNTER  36
#define SENSOR_BEFORE  39
#define SENSOR_AFTER   34
#define SENSOR_Q1      35
#define SENSOR_Q2      32
#define SENSOR_Q3      33
#define COLOR_SENSOR   25  // Analog input pin

/* ==================
 *  Global Variables
 * ================== */
String currentColor = "Nothing";
String detectedColor = "Nothing";

volatile unsigned int pulseCount = 0;
float lastVoltage = 0.0;

bool colorDetected = false;

// Minimum voltage for the current piece
float pieceMinVoltage = 3.3f;

// IMPORTANT:
// Replace BLUE_MIN_V with the measured Min voltage for blue from your calibration run.
const float WHITE_MIN_V = 0.8002f;
const float RED_MIN_V   = 1.6222f;
const float BLUE_MIN_V  = 2.0000f;   // <-- عدّل هذه القيمة حسب Min voltage للأزرق

const float THRESHOLD_RED_WHITE = (RED_MIN_V + WHITE_MIN_V) / 2.0f;  // 1.2112 تقريباً
const float THRESHOLD_BLUE_RED  = (BLUE_MIN_V + RED_MIN_V) / 2.0f;
const float THRESHOLD_WHITE_MIN = 0.7000f;

// Valve pushes and stop flag
volatile unsigned int valvePushCount = 0;   // total number of valve actuations
volatile bool stopFlag = false;             // set true when valvePushCount reaches 9 (optional)

/* =======================================================
 *  "Latched-Low" State for Queue Sensors (Q1, Q2, Q3)
 *  - On first falling edge (HIGH->LOW), we set qBlockHigh[i]=true
 *    and from then, readQ(i) always returns LOW until reset.
 * ======================================================= */
volatile bool qBlockHigh[3] = {false, false, false};
volatile int  qPrevRaw[3]   = {HIGH, HIGH, HIGH};

static inline int pinForQIndex(int idx) {
  switch (idx) {
    case 0: return SENSOR_Q1;
    case 1: return SENSOR_Q2;
    case 2: return SENSOR_Q3;
    default: return SENSOR_Q1;
  }
}

// Update edge/latch states for Q sensors; call periodically
static inline void updateQBlocks() {
  for (int i = 0; i < 3; ++i) {
    int pin = pinForQIndex(i);
    int raw = digitalRead(pin);

    // Latch on falling edge: HIGH -> LOW
    if (qPrevRaw[i] == HIGH && raw == LOW) {
      qBlockHigh[i] = true;
    }

    qPrevRaw[i] = raw;
  }
}

// Read Q sensor with "latched-low" behavior
static inline int readQ(int idx) {
  updateQBlocks();

  if (qBlockHigh[idx]) {
    return LOW;
  }

  int pin = pinForQIndex(idx);
  return digitalRead(pin);
}

// Reset all Q latches
static inline void resetQBlocks() {
  for (int i = 0; i < 3; ++i) {
    qBlockHigh[i] = false;
    int pin = pinForQIndex(i);
    qPrevRaw[i] = digitalRead(pin);
  }
}

/* ==========================
 *  ISR for Pulse Counting
 * ========================== */
void IRAM_ATTR countPulse() {
  pulseCount++;
}

/* =================
 *  Initialization
 * ================= */
void setup() {
  Serial.begin(115200);

  pinMode(BELT_MOTOR, OUTPUT);
  pinMode(COMPRESSOR, OUTPUT);
  pinMode(VALVE_WHITE, OUTPUT);
  pinMode(VALVE_RED, OUTPUT);
  pinMode(VALVE_BLUE, OUTPUT);

  pinMode(PULSE_COUNTER, INPUT);
  pinMode(SENSOR_BEFORE, INPUT);
  pinMode(SENSOR_AFTER, INPUT);
  pinMode(SENSOR_Q1, INPUT);
  pinMode(SENSOR_Q2, INPUT);
  pinMode(SENSOR_Q3, INPUT);
  pinMode(COLOR_SENSOR, INPUT);

  qPrevRaw[0] = digitalRead(SENSOR_Q1);
  qPrevRaw[1] = digitalRead(SENSOR_Q2);
  qPrevRaw[2] = digitalRead(SENSOR_Q3);

  attachInterrupt(digitalPinToInterrupt(PULSE_COUNTER), countPulse, CHANGE);

  xTaskCreatePinnedToCore(serialLoggerTask, "SerialLogger", 4096, NULL, 1, NULL, 1);
}

/* ====================
 *  Color Reading
 * ==================== */
void detectColor() {
  int sensorValue = analogRead(COLOR_SENSOR);
  float voltage = sensorValue * (3.3f / 4095.0f);
  lastVoltage = voltage;

  if (voltage > 0.05f && voltage < pieceMinVoltage) {
    pieceMinVoltage = voltage;
  }
}

/* ==========================================
 *  Decide final color from pieceMinVoltage
 * ========================================== */
void decideColorFromMinVoltage() {
  if (pieceMinVoltage > THRESHOLD_BLUE_RED) {
    detectedColor = "Blue";
  } else if (pieceMinVoltage > THRESHOLD_RED_WHITE) {
    detectedColor = "Red";
  } else if (pieceMinVoltage > THRESHOLD_WHITE_MIN) {
    detectedColor = "White";
  } else {
    detectedColor = "Nothing";
  }
}

/* ======================================
 *  Generalized Sorting Movement
 * ====================================== */
void moveAndSort(int targetPulse, int valvePin) {
  while (pulseCount <= targetPulse) {
    digitalWrite(BELT_MOTOR, HIGH);
    // delay(1);
  }

  digitalWrite(BELT_MOTOR, LOW);

  digitalWrite(COMPRESSOR, HIGH);
  digitalWrite(valvePin, HIGH);
  delay(200);
  digitalWrite(valvePin, LOW);
  digitalWrite(COMPRESSOR, LOW);

  valvePushCount++;

  resetQBlocks();

  // Optional: stop after 9 pushes
  // if (valvePushCount >= 9) {
  //   stopFlag = true;
  // }
}

/* ================================
 *  Decision Logic for Sorting
 * ================================ */
void processSorting() {
  if (digitalRead(SENSOR_BEFORE) == LOW && detectedColor == "Nothing") {
    pieceMinVoltage = 3.3f;

    // Move belt while piece is between BEFORE (LOW) and AFTER (HIGH)
    while (digitalRead(SENSOR_AFTER) == HIGH) {
      digitalWrite(BELT_MOTOR, HIGH);
      detectColor();
      delay(10);
    }

    digitalWrite(BELT_MOTOR, LOW);

    // Decide color from minimum voltage collected during passage
    decideColorFromMinVoltage();

    // Reset pulse count AFTER object leaves color sensor
    pulseCount = 0;

    // Perform sorting by detectedColor
    if (detectedColor == "White") {
      moveAndSort(110, VALVE_WHITE);
    } else if (detectedColor == "Red") {
      moveAndSort(280, VALVE_RED);
    } else if (detectedColor == "Blue") {
      moveAndSort(480, VALVE_BLUE);
    } else {
      // No valid color detected -> do nothing
    }

    // Reset detection state
    detectedColor = "Nothing";
    currentColor = "Nothing";
    pieceMinVoltage = 3.3f;
    colorDetected = false;
  }
}

/* ===================
 *  Serial Logger Task
 * =================== */
void serialLoggerTask(void *pvParameters) {
  Serial.println(
    "timestamp(ms),"
    "BELT_MOTOR,COMPRESSOR,VALVE_WHITE,VALVE_RED,VALVE_BLUE,"
    "SENSOR_BEFORE,SENSOR_AFTER,SENSOR_Q1,SENSOR_Q2,SENSOR_Q3,"
    "COLOR_CODE,VALVE_PUSH_COUNT,STOP_FLAG"
  );

  bool detecting = false;
  float loggerMinVoltage = 3.3f;

  while (true) {
    unsigned long ts = millis();
    Serial.print(ts);

    auto logPin = [](int pin) {
      Serial.print(",");
      Serial.print(digitalRead(pin));
    };

    // Actuators (raw)
    logPin(BELT_MOTOR);
    logPin(COMPRESSOR);
    logPin(VALVE_WHITE);
    logPin(VALVE_RED);
    logPin(VALVE_BLUE);

    // BEFORE/AFTER (raw)
    int before = digitalRead(SENSOR_BEFORE);
    int after  = digitalRead(SENSOR_AFTER);
    Serial.print(","); Serial.print(before);
    Serial.print(","); Serial.print(after);

    // Q1–Q3: filtered (latched-low)
    int q1 = readQ(0);
    int q2 = readQ(1);
    int q3 = readQ(2);
    Serial.print(","); Serial.print(q1);
    Serial.print(","); Serial.print(q2);
    Serial.print(","); Serial.print(q3);

    // Final color code
    float finalCode = 0.0f;

    if (!detecting && before == LOW && after == HIGH) {
      detecting = true;
      loggerMinVoltage = 3.3f;
    }

    if (detecting) {
      int sensorValue = analogRead(COLOR_SENSOR);
      float voltage = sensorValue * (3.3f / 4095.0f);
      lastVoltage = voltage;

      if (voltage > 0.05f && voltage < loggerMinVoltage) {
        loggerMinVoltage = voltage;
      }
    }

    if (detecting && after == LOW) {
      detecting = false;

      if (loggerMinVoltage > THRESHOLD_BLUE_RED) {
        finalCode = 0.3f;  // Blue
      } else if (loggerMinVoltage > THRESHOLD_RED_WHITE) {
        finalCode = 0.2f;  // Red
      } else if (loggerMinVoltage > THRESHOLD_WHITE_MIN) {
        finalCode = 0.1f;  // White
      } else {
        finalCode = 0.0f;  // Nothing
      }
    }

    Serial.print(","); Serial.print(finalCode, 1);
    Serial.print(","); Serial.print(valvePushCount);
    Serial.print(","); Serial.print(stopFlag ? 1 : 0);

    Serial.println();
    vTaskDelay(pdMS_TO_TICKS(20));
  }
}

/* ===========
 *  Main Loop
 * =========== */
void loop() {
  processSorting();
}