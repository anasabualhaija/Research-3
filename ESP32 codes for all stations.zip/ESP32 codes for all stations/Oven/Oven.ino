// ==============================
//     Pin Definitions
// ==============================
#define RS_Table_vacum_position 36
#define RS_Table_belt_position 39
#define Belt_Light_Bar 34
#define RS_Table_Saw_position 35
#define RS_Vacum_Table_position 32
#define RS_Vacum_Oven_position 33
#define Oven_Light_Bar 25

#define Move_Table_TO_belt 23
#define Move_Table_TO_Vacuum 22
#define Belt_Motor 21
#define Saw_Motor 19
#define Move_Vacuum_To_OvenPin 18
#define Move_Vacuum_To_TablePin 17
#define Oven_Light 16
#define Compressor  4
#define Gripper     2
#define Vacuum_Valve 14
#define Oven_DoorPin 12
#define Table_Valve 13
#define RS_Oven_Feed_In 5
#define RS_Oven_Feed_Out 15
#define Move_Oven_inside 26
#define Move_Oven_outside 27

// ==============================
//     Constants
// ==============================
const uint16_t VAC_PICK_DWELL_MS = 1000;  // dwell time for vacuum pick (DOWN wait UP)

// ==============================
//     Shared State Variables
// ==============================
volatile bool oven_has_piece = false;
volatile bool piece_is_heated = false;
volatile bool door_is_open = false;
volatile bool feeder_is_out = true;
volatile bool new_piece_detected = false;
volatile bool vacuum_at_oven = false;
volatile bool vacuum_at_table = false;
volatile bool vacuum_holding_piece = false;
volatile bool table_at_vacuum_pos = false;
volatile bool table_has_piece = false;

unsigned long feeder_detection_time = 0;
bool feeder_timer_started = false;

unsigned long heating_start_time = 0;
bool heating_timer_started = false;

// legacy (not used by the new pick lift sequence)
unsigned long vacuum_pick_start_time = 0;
bool vacuum_pick_timer_started = false;

volatile unsigned long light_barrier_ignore_until = 0;

TaskHandle_t TaskInputsHandle;
TaskHandle_t TaskOvenHandle;
TaskHandle_t TaskVacuumHandle;
TaskHandle_t TaskTableHandle;

// ==============================
//     Command Params (current recipe)
// ==============================
volatile bool recipe_active = false;          // machine acts only when a recipe is armed
volatile bool skip_oven = false;              // "no machining"
volatile uint32_t heating_duration_ms = 1000; // base heating (from recipe)

// Saw pattern (general runner)
const uint8_t SAW_MAX_SEGMENTS = 8;
volatile uint16_t sawPatternDur[SAW_MAX_SEGMENTS] = {1000};
volatile bool     sawPatternOn [SAW_MAX_SEGMENTS] = {true};
volatile uint8_t  sawPatternLen = 1;
volatile uint8_t  sawPatternIdx = 0;

// Current heating target (can be overridden in reheat mode)
uint32_t current_heating_ms = 1000;

// ==============================
//   Special reheat (advanced+clean+paint)
// ==============================
volatile bool special_reheat_after_saw_active = false; // set by recipe parser for this job only
volatile uint32_t special_reheat_ms = 2000;            // 2s reheat

// Rework coordination
volatile bool rework_active = false;   // true while doing the post-saw reheat flow
volatile uint8_t rework_stage = 0;     // 0=none, 1=pending pick @table, 2=carry to oven & place, 3=returned to table

// After reheat, run a second saw?
volatile bool post_reheat_second_saw_pending = false;

// Place target: table or oven feeder
volatile bool place_target_is_table = true;

// Reheat override selection
volatile bool reheat_mode_active = false;
volatile uint32_t reheat_duration_ms = 2000;

// ==============================
//     FIFO queue for recipes
// ==============================
struct Recipe {
  bool skip_oven;
  uint32_t heat_ms;
  uint8_t sawLen;
  uint16_t sawDur[SAW_MAX_SEGMENTS];
  bool sawOn[SAW_MAX_SEGMENTS];

  // special flag
  bool special_reheat_after_saw;
  uint32_t special_reheat_ms;
};

#define CMD_QUEUE_CAP 16
Recipe cmdQueue[CMD_QUEUE_CAP];
volatile uint8_t qHead = 0;  // next write
volatile uint8_t qTail = 0;  // next read

inline bool queueIsEmpty() { return qHead == qTail; }
inline bool queueIsFull()  { return (uint8_t)(qHead + 1) % CMD_QUEUE_CAP == qTail; }

bool enqueueRecipe(const Recipe &r) {
  uint8_t next = (uint8_t)(qHead + 1) % CMD_QUEUE_CAP;
  if (next == qTail) return false;
  cmdQueue[qHead] = r;
  qHead = next;
  return true;
}

bool dequeueRecipe(Recipe &out) {
  if (qHead == qTail) return false;
  out = cmdQueue[qTail];
  qTail = (uint8_t)(qTail + 1) % CMD_QUEUE_CAP;
  return true;
}

void clearQueue() { qHead = qTail = 0; }

volatile bool currentRecipeValid = false;

void armNextRecipeIfAvailable() {
  if (currentRecipeValid) return;
  Recipe r;
  if (!dequeueRecipe(r)) {
    recipe_active = false;
    return;
  }
  skip_oven = r.skip_oven;
  heating_duration_ms = r.heat_ms;

  noInterrupts();
  sawPatternLen = r.sawLen;
  for (uint8_t i = 0; i < sawPatternLen && i < SAW_MAX_SEGMENTS; ++i) {
    sawPatternDur[i] = r.sawDur[i];
    sawPatternOn[i]  = r.sawOn[i];
  }
  special_reheat_after_saw_active = r.special_reheat_after_saw;
  special_reheat_ms = r.special_reheat_ms;
  rework_active = false;
  rework_stage = 0;
  post_reheat_second_saw_pending = false;
  interrupts();

  recipe_active = true;
  currentRecipeValid = true;

  Serial.print("[ARM] "); Serial.print(skip_oven ? "NO MACHINING" : "WITH OVEN");
  Serial.print(" | Heat(ms)="); Serial.print((uint32_t)heating_duration_ms);
  Serial.print(" | Saw=");
  if (sawPatternLen == 0) Serial.print("none");
  else {
    for (uint8_t i = 0; i < sawPatternLen; ++i) {
      Serial.print(sawPatternOn[i] ? "ON " : "OFF "); Serial.print(sawPatternDur[i]); Serial.print("ms");
      if (i + 1 < sawPatternLen) Serial.print(" -> ");
    }
  }
  if (special_reheat_after_saw_active) {
    Serial.print(" | SPECIAL ReheatAfterSaw="); Serial.print((uint32_t)special_reheat_ms); Serial.print("ms");
  }
  Serial.println();
}

void finishCycleAndMaybeArmNext() {
  recipe_active = false;
  currentRecipeValid = false;

  new_piece_detected = false;
  feeder_timer_started = false;
  heating_timer_started = false;
  vacuum_pick_timer_started = false;
  oven_has_piece = false;
  piece_is_heated = false;
  vacuum_holding_piece = false;

  rework_active = false;
  rework_stage = 0;
  special_reheat_after_saw_active = false;
  reheat_mode_active = false;
  post_reheat_second_saw_pending = false;

  if (!queueIsEmpty()) armNextRecipeIfAvailable();
  else Serial.println("[CYCLE] Complete. Queue empty — waiting for new command...");
}

// ==============================
//     Enums for State Machines
// ==============================
enum OvenStates {
  OV_IDLE,
  OV_OPEN_DOOR_TO_RECEIVE,
  OV_FEED_IN,
  OV_CLOSE_DOOR_TO_HEAT,
  OV_HEATING,
  OV_OPEN_DOOR_TO_UNLOAD,
  OV_FEED_OUT,
  OV_COMPLETE
};
volatile OvenStates ovenState = OV_IDLE;

enum VacuumStates {
  VAC_IDLE,
  VAC_GO_TO_OVEN,
  VAC_PICK_PIECE,
  VAC_GO_TO_TABLE,
  VAC_PLACE_PIECE,
  VAC_RETURN_IDLE
};
volatile VacuumStates vacuumState = VAC_IDLE;

enum VacuumPlaceSubState { VP_IDLE, VP_VALVE_ON_WAIT, VP_RELEASE };
VacuumPlaceSubState vacuumPlaceSubState = VP_IDLE;
unsigned long vacuum_place_start_time = 0;

// Robust pick sub-state (down -> dwell -> up)
enum VacuumPickLiftSubState { VPK_IDLE, VPK_SUCK_WAIT, VPK_LIFT_DONE };
VacuumPickLiftSubState vacuumPickLiftSubState = VPK_IDLE;
unsigned long vpk_action_start_time = 0;
// remember where we started the pick from (oven/table)
volatile bool pick_from_table = false;

enum TableSubStates { SAW_IDLE, SAW_RUNNING };
TableSubStates sawSubState = SAW_IDLE;
unsigned long saw_start_time = 0;

enum TablePushSubStates { PUSH_IDLE, PUSH_VALVE_WAIT };
TablePushSubStates pushSubState = PUSH_IDLE;
unsigned long table_push_start_time = 0;

enum BeltRunSubState { BELT_IDLE, BELT_WAIT_EXTRA };
BeltRunSubState beltSubState = BELT_IDLE;
unsigned long belt_run_extra_start_time = 0;

enum TableStates {
  TAB_IDLE,
  TAB_MOVE_TO_VACUUM,
  TAB_READY,
  TAB_MOVE_TO_SAW,
  TAB_AT_SAW,
  TAB_MOVE_TO_BELT,
  TAB_PUSH_TO_BELT,
  TAB_RUN_BELT,
  TAB_WAIT_REWORK_PICK
};
volatile TableStates tableState = TAB_IDLE;

// ==============================
//     Forward Declarations
// ==============================
void TaskReadInputs(void *pvParameters);
void TaskOven(void *pvParameters);
void TaskVacuum(void *pvParameters);
void TaskTable(void *pvParameters);
void serialLoggerTask(void *pvParameters);
void serialCommandTask(void *pvParameters);
void Ready();
void applySawSegment(uint8_t idx);

// ==============================
//     Setup / Loop
// ==============================
void setup() {
  Serial.begin(115200);

  pinMode(RS_Table_vacum_position, INPUT);
  pinMode(RS_Table_belt_position, INPUT);
  pinMode(Belt_Light_Bar, INPUT);
  pinMode(RS_Table_Saw_position, INPUT);
  pinMode(RS_Vacum_Table_position, INPUT);
  pinMode(RS_Vacum_Oven_position, INPUT);
  pinMode(Oven_Light_Bar, INPUT);
  pinMode(RS_Oven_Feed_In, INPUT);
  pinMode(RS_Oven_Feed_Out, INPUT);

  pinMode(Move_Table_TO_belt, OUTPUT);
  pinMode(Move_Table_TO_Vacuum, OUTPUT);
  pinMode(Belt_Motor, OUTPUT);
  pinMode(Saw_Motor, OUTPUT);
  pinMode(Move_Vacuum_To_OvenPin, OUTPUT);
  pinMode(Move_Vacuum_To_TablePin, OUTPUT);
  pinMode(Oven_Light, OUTPUT);
  pinMode(Compressor, OUTPUT);
  pinMode(Gripper, OUTPUT);
  pinMode(Vacuum_Valve, OUTPUT);
  pinMode(Oven_DoorPin, OUTPUT);
  pinMode(Table_Valve, OUTPUT);
  pinMode(Move_Oven_inside, OUTPUT);
  pinMode(Move_Oven_outside, OUTPUT);

  xTaskCreatePinnedToCore(TaskReadInputs, "TaskReadInputs", 4096, NULL, 2, &TaskInputsHandle, 0);
  xTaskCreatePinnedToCore(TaskOven, "TaskOven", 4096, NULL, 1, &TaskOvenHandle, 0);
  xTaskCreatePinnedToCore(TaskVacuum, "TaskVacuum", 4096, NULL, 1, &TaskVacuumHandle, 1);
  xTaskCreatePinnedToCore(TaskTable, "TaskTable", 4096, NULL, 1, &TaskTableHandle, 1);
  xTaskCreatePinnedToCore(serialLoggerTask, "SerialLogger", 4096, NULL, 1, NULL, 1);
  xTaskCreatePinnedToCore(serialCommandTask, "SerialCmd", 4096, NULL, 1, NULL, 1);

  Ready();

  recipe_active = false;
  currentRecipeValid = false;
  Serial.println("FIFO ready. Each line = one recipe:");
  Serial.println("  no machining, cleaning, painting");
  Serial.println("  basic shape, cleaning");
  Serial.println("  advance shape, cleaning, painting  (SPECIAL: reheat 2s as NEW, then second saw 2-1-2)");
  Serial.println("  extra shape");
  Serial.println("  stop  (clears queue and disarms)");
}

void loop() {}

// ==============================
//     Input Task (LB trigger)
// ==============================
void TaskReadInputs(void *pvParameters) {
  static bool last_oven_light_state = HIGH;

  while (true) {
    bool current_state = digitalRead(Oven_Light_Bar);
    if (current_state != last_oven_light_state && current_state == LOW) {
      if (millis() > light_barrier_ignore_until) {
        new_piece_detected = true;
        Serial.println("[LB] LOW -> piece detected (armed)");
      }
    }
    last_oven_light_state = current_state;

    feeder_is_out = digitalRead(RS_Oven_Feed_Out) == HIGH;
    if (digitalRead(RS_Oven_Feed_In) == HIGH) digitalWrite(Move_Oven_inside, LOW);
    if (feeder_is_out) digitalWrite(Move_Oven_outside, LOW);

    vacuum_at_oven  = digitalRead(RS_Vacum_Oven_position)  == HIGH;
    vacuum_at_table = digitalRead(RS_Vacum_Table_position) == HIGH;
    table_at_vacuum_pos = digitalRead(RS_Table_vacum_position) == HIGH;

    if (vacuum_at_oven)  digitalWrite(Move_Vacuum_To_OvenPin, LOW);
    if (vacuum_at_table) digitalWrite(Move_Vacuum_To_TablePin, LOW);
    if (table_at_vacuum_pos) digitalWrite(Move_Table_TO_Vacuum, LOW);

    vTaskDelay(pdMS_TO_TICKS(20));
  }
}

// ==============================
//     Oven Task
// ==============================
void TaskOven(void *pvParameters) {
  while (true) {
    if (!recipe_active) { vTaskDelay(pdMS_TO_TICKS(20)); continue; }

    if (skip_oven) {
      ovenState = OV_IDLE;
      digitalWrite(Oven_Light, LOW);
      digitalWrite(Oven_DoorPin, LOW);
      vTaskDelay(pdMS_TO_TICKS(20));
      continue;
    }

    switch (ovenState) {
      case OV_IDLE:
        if (new_piece_detected && !oven_has_piece && !feeder_timer_started) {
          feeder_detection_time = millis();
          feeder_timer_started = true;
        }
        if (feeder_timer_started && millis() - feeder_detection_time >= 2000) {
          new_piece_detected = false;
          feeder_timer_started = false;
          ovenState = OV_OPEN_DOOR_TO_RECEIVE;
        }
        break;

      case OV_OPEN_DOOR_TO_RECEIVE:
        if (!door_is_open) {
          digitalWrite(Compressor, HIGH); // air for door
          digitalWrite(Oven_DoorPin, HIGH);
          door_is_open = true;
        }
        if (feeder_is_out) {
          ovenState = OV_FEED_IN;
        }
        break;

      case OV_FEED_IN:
        digitalWrite(Move_Oven_inside, HIGH);
        if (digitalRead(RS_Oven_Feed_In) == HIGH) {
          oven_has_piece = true;
          ovenState = OV_CLOSE_DOOR_TO_HEAT;
        }
        break;

      case OV_CLOSE_DOOR_TO_HEAT:
        if (door_is_open) {
          digitalWrite(Oven_DoorPin, LOW);
          door_is_open = false;
        } else {
          ovenState = OV_HEATING;
        }
        break;

      case OV_HEATING:
        if (!piece_is_heated) {
          if (!heating_timer_started) {
            digitalWrite(Oven_Light, HIGH);
            digitalWrite(Compressor, LOW);          // LOW while heating light is ON
            heating_start_time = millis();
            heating_timer_started = true;

            current_heating_ms = reheat_mode_active ? reheat_duration_ms : heating_duration_ms;
            Serial.print("[OVEN] Heating for "); Serial.print((uint32_t)current_heating_ms); Serial.println(" ms");
          } else if (millis() - heating_start_time >= current_heating_ms) {
            digitalWrite(Oven_Light, LOW);
            digitalWrite(Compressor, HIGH);         // HIGH when heating completes
            piece_is_heated = true;
            heating_timer_started = false;
            reheat_mode_active = false;
          }
        } else {
          ovenState = OV_OPEN_DOOR_TO_UNLOAD;
        }
        break;

      case OV_OPEN_DOOR_TO_UNLOAD:
        if (!door_is_open) {
          digitalWrite(Compressor, HIGH);
          digitalWrite(Oven_DoorPin, HIGH);
          door_is_open = true;
        }
        if (!feeder_is_out) {
          ovenState = OV_FEED_OUT;
        }
        break;

      case OV_FEED_OUT:
        digitalWrite(Move_Oven_outside, HIGH);
        if (feeder_is_out) {
          digitalWrite(Move_Oven_outside, LOW);
          if (door_is_open) {
            digitalWrite(Oven_DoorPin, LOW);
            door_is_open = false;
          }
          // keep compressor OFF after piece exits, until vacuum arrives to the oven
          digitalWrite(Compressor, LOW);
          ovenState = OV_COMPLETE;
        }
        break;

      case OV_COMPLETE:
        if (!oven_has_piece) {
          piece_is_heated = false;
          ovenState = OV_IDLE;
        }
        break;
    }
    vTaskDelay(pdMS_TO_TICKS(20));
  }
}

// ==============================
//     Vacuum Task
// ==============================
void TaskVacuum(void *pvParameters) {
  while (true) {
    if (!recipe_active) { vTaskDelay(pdMS_TO_TICKS(20)); continue; }

    if (vacuumState == VAC_IDLE || vacuumState == VAC_RETURN_IDLE) {
      digitalWrite(Move_Vacuum_To_OvenPin, LOW);
      digitalWrite(Move_Vacuum_To_TablePin, LOW);
    }

    switch (vacuumState) {
      case VAC_IDLE:
        if (vacuum_holding_piece) {
          vacuumState = VAC_GO_TO_TABLE;

        } else if (rework_active && rework_stage == 1 && table_at_vacuum_pos && table_has_piece) {
          // pick from table (special reheat flow)
          vacuumState = VAC_GO_TO_TABLE;

        } else if (skip_oven) {
          // NO machining: go as soon as LB LOW (we clear the LB flag here)
          if (new_piece_detected) { new_piece_detected = false; vacuumState = VAC_GO_TO_OVEN; }

        } else {
          // WITH oven: pre-position to oven as soon as LB LOW or job is in progress
          // (no dependency on feeder_is_out anymore)
          bool preposition_to_oven = (new_piece_detected || feeder_timer_started || oven_has_piece || piece_is_heated);
          if (preposition_to_oven) vacuumState = VAC_GO_TO_OVEN;
        }
        break;

      case VAC_GO_TO_OVEN:
        if (!vacuum_at_oven) {
          digitalWrite(Move_Vacuum_To_TablePin, LOW);
          digitalWrite(Move_Vacuum_To_OvenPin, HIGH);
        } else {
          digitalWrite(Move_Vacuum_To_OvenPin, LOW);
          //digitalWrite(Compressor, HIGH); // air for placement/pick

          if (rework_active && rework_stage == 2 && vacuum_holding_piece) {
            // SPECIAL: place on feeder, then treat as NEW with 2s heat
            reheat_mode_active = true;
            reheat_duration_ms = special_reheat_ms;
            place_target_is_table = false;          // target = OVEN FEEDER
            vacuumState = VAC_PLACE_PIECE;
          } else {
            vacuumState = VAC_PICK_PIECE;           // wait here until feeder is actually out
          }
        }
        break;

      case VAC_PICK_PIECE: {
        // Robust "down -> dwell -> up" sequence
        bool can_pick_from_table = (rework_active && rework_stage == 1 && vacuum_at_table && table_at_vacuum_pos && table_has_piece);
        bool can_pick_from_oven  = (feeder_is_out && (ovenState == OV_FEED_OUT || skip_oven || piece_is_heated)) && vacuum_at_oven;

        // Start the pick sequence only when target is ready
        if (vacuumPickLiftSubState == VPK_IDLE && !vacuum_holding_piece && (can_pick_from_table || can_pick_from_oven)) {
          // remember source
          pick_from_table = can_pick_from_table;

          // ignore LB noise while picking
          light_barrier_ignore_until = millis() + 2000;

          // ensure air, go DOWN and start vacuum valve
          digitalWrite(Compressor, HIGH);
          digitalWrite(Gripper, LOW);        // go DOWN
          digitalWrite(Vacuum_Valve, HIGH);  // engage vacuum/clamp assist

          vpk_action_start_time = millis();
          vacuumPickLiftSubState = VPK_SUCK_WAIT;   // dwell here VAC_PICK_DWELL_MS
        }

        if (vacuumPickLiftSubState == VPK_SUCK_WAIT) {
          if (millis() - vpk_action_start_time >= VAC_PICK_DWELL_MS) {
            // lift UP after dwell
            digitalWrite(Gripper, HIGH);     // go UP
            digitalWrite(Vacuum_Valve, LOW); // restore valve state
            vacuumPickLiftSubState = VPK_LIFT_DONE;
          }
        }

        if (vacuumPickLiftSubState == VPK_LIFT_DONE) {
          // finalize pick
          vacuum_holding_piece = true;

          if (pick_from_table) {
            table_has_piece = false;
            rework_stage = 2;                // carry to oven & place
            vacuumState = VAC_GO_TO_OVEN;
          } else {
            oven_has_piece = false;
            vacuumState = VAC_GO_TO_TABLE;
          }

          // reset sub-state
          vacuumPickLiftSubState = VPK_IDLE;
        }
      } break;

      case VAC_GO_TO_TABLE:
        if (!vacuum_at_table) {
          digitalWrite(Move_Vacuum_To_OvenPin, LOW);
          digitalWrite(Move_Vacuum_To_TablePin, HIGH);
        } else {
          digitalWrite(Move_Vacuum_To_TablePin, LOW);
          if (vacuum_holding_piece) {
            place_target_is_table = true;
            vacuumState = VAC_PLACE_PIECE;
          } else if (rework_active && rework_stage == 1 && table_has_piece) {
            vacuumState = VAC_PICK_PIECE;
          } else {
            vacuumState = VAC_RETURN_IDLE;
          }
        }
        break;

      case VAC_PLACE_PIECE: {
        // Place either on TABLE or OVEN FEEDER (feeder must be OUT for oven)
        bool target_ready = place_target_is_table ? table_at_vacuum_pos : feeder_is_out;
        if (!target_ready) break;

        switch (vacuumPlaceSubState) {
          case VP_IDLE:
            digitalWrite(Vacuum_Valve, HIGH);
            vacuum_place_start_time = millis();
            vacuumPlaceSubState = VP_VALVE_ON_WAIT;
            break;

          case VP_VALVE_ON_WAIT:
            if (millis() - vacuum_place_start_time >= 500) {
              digitalWrite(Gripper, LOW);    // go DOWN to place
              vacuum_place_start_time = millis();
              vacuumPlaceSubState = VP_RELEASE;
            }
            break;

          case VP_RELEASE:
            if (millis() - vacuum_place_start_time >= 500) {
              digitalWrite(Vacuum_Valve, LOW);
              vacuum_holding_piece = false;

              if (place_target_is_table) {
                // placed on TABLE
                table_has_piece = true;
                digitalWrite(Compressor, LOW);    // compressor LOW when placed on table

              } else {
                // placed on OVEN feeder → treat as NEW part with 2s heat
                new_piece_detected = true;        // oven will do 2s wait, then receive
              }

              digitalWrite(Move_Vacuum_To_OvenPin, LOW);
              digitalWrite(Move_Vacuum_To_TablePin, LOW);
              vacuumPlaceSubState = VP_IDLE;
              vacuumState = VAC_RETURN_IDLE;
            }
            break;
        }
      } break;

      case VAC_RETURN_IDLE:
        digitalWrite(Move_Vacuum_To_OvenPin, LOW);
        digitalWrite(Move_Vacuum_To_TablePin, LOW);

        // If the reheated piece was returned to table, mark stage 3 so table can run second saw
        if (rework_active && !vacuum_holding_piece && table_has_piece && place_target_is_table && rework_stage == 2) {
          rework_stage = 3;
          post_reheat_second_saw_pending = true; // request the second saw 2-1-2
        }

        vacuumState = VAC_IDLE;
        break;
    }
    vTaskDelay(pdMS_TO_TICKS(20));
  }
}

// ==============================
//     Table Task (saw + reheat flow)
// ==============================
void TaskTable(void *pvParameters) {
  while (true) {
    if (!recipe_active) {
      if (!currentRecipeValid && !queueIsEmpty()) armNextRecipeIfAvailable();
      vTaskDelay(pdMS_TO_TICKS(20));
      continue;
    }

    switch (tableState) {
      case TAB_IDLE:
        if (!table_at_vacuum_pos &&
            ((skip_oven && !vacuum_holding_piece && !table_has_piece && !oven_has_piece && new_piece_detected) ||
             (!skip_oven && piece_is_heated && oven_has_piece))) {
          tableState = TAB_MOVE_TO_VACUUM;
        } else if (table_at_vacuum_pos && table_has_piece) {
          tableState = TAB_READY;
        }
        break;

      case TAB_MOVE_TO_VACUUM:
        if (!table_at_vacuum_pos) digitalWrite(Move_Table_TO_Vacuum, HIGH);
        if (table_at_vacuum_pos) {
          digitalWrite(Move_Table_TO_Vacuum, LOW);
          if (rework_active && rework_stage == 1) tableState = TAB_WAIT_REWORK_PICK;
          else tableState = TAB_READY;
        }
        break;

      case TAB_READY:
        if (table_has_piece) tableState = TAB_MOVE_TO_SAW;
        break;

      case TAB_MOVE_TO_SAW:
        digitalWrite(Move_Table_TO_belt, HIGH);
        if (digitalRead(RS_Table_Saw_position) == HIGH) {
          digitalWrite(Move_Table_TO_belt, LOW);
          tableState = TAB_AT_SAW;
        }
        break;

      case TAB_AT_SAW:
        // If no saw requested, go straight to belt
        if (sawPatternLen == 0) {
          digitalWrite(Compressor, HIGH);
          tableState = TAB_MOVE_TO_BELT;
          break;
        }
        switch (sawSubState) {
          case SAW_IDLE:
            sawPatternIdx = 0;
            applySawSegment(sawPatternIdx);
            saw_start_time = millis();
            sawSubState = SAW_RUNNING;
            break;

          case SAW_RUNNING:
            if (sawPatternIdx < sawPatternLen &&
                (millis() - saw_start_time >= sawPatternDur[sawPatternIdx])) {
              sawPatternIdx++;
              if (sawPatternIdx < sawPatternLen) {
                applySawSegment(sawPatternIdx);
                saw_start_time = millis();
              } else {
                digitalWrite(Saw_Motor, LOW);
                digitalWrite(Compressor, HIGH);    // HIGH after saw finishes

                // Branching:
                // 1) First saw of special flow -> go do reheat
                if (special_reheat_after_saw_active && rework_active == false) {
                  rework_active = true;
                  rework_stage = 1;                // wait at vacuum for pick for reheat
                  tableState = TAB_MOVE_TO_VACUUM;

                // 2) Second saw (after reheat) -> proceed to belt
                } else if (rework_active && rework_stage == 3 && post_reheat_second_saw_pending) {
                  post_reheat_second_saw_pending = false;
                  tableState = TAB_MOVE_TO_BELT;

                // 3) Normal job: proceed to belt
                } else {
                  tableState = TAB_MOVE_TO_BELT;
                }

                sawSubState = SAW_IDLE;
              }
            }
            break;
        }
        break;

      case TAB_WAIT_REWORK_PICK:
        // After reheat, when piece is placed back on table, run a second saw (2-1-2)
        if (rework_active && rework_stage == 3 && table_has_piece && post_reheat_second_saw_pending) {
          tableState = TAB_MOVE_TO_SAW;
        }
        break;

      case TAB_MOVE_TO_BELT:
        digitalWrite(Move_Table_TO_belt, HIGH);
        if (digitalRead(RS_Table_belt_position) == HIGH) {
          digitalWrite(Move_Table_TO_belt, LOW);
          tableState = TAB_PUSH_TO_BELT;
        }
        break;

      case TAB_PUSH_TO_BELT:
        switch (pushSubState) {
          case PUSH_IDLE:
            digitalWrite(Compressor, HIGH);
            digitalWrite(Table_Valve, HIGH);
            table_push_start_time = millis();
            pushSubState = PUSH_VALVE_WAIT;
            break;
          case PUSH_VALVE_WAIT:
            if (millis() - table_push_start_time >= 500) {
              digitalWrite(Table_Valve, LOW);
              pushSubState = PUSH_IDLE;
              digitalWrite(Compressor, LOW); // compressor LOW after push
              tableState = TAB_RUN_BELT;
            }
            break;
        }
        break;

      case TAB_RUN_BELT:
        switch (beltSubState) {
          case BELT_IDLE:
            digitalWrite(Belt_Motor, HIGH);
            if (digitalRead(Belt_Light_Bar) == LOW) {
              belt_run_extra_start_time = millis();
              beltSubState = BELT_WAIT_EXTRA;
            }
            break;

          case BELT_WAIT_EXTRA:
            if (millis() - belt_run_extra_start_time >= 2000) {
              digitalWrite(Belt_Motor, LOW);
              table_has_piece = false;

              tableState = TAB_MOVE_TO_VACUUM;
              beltSubState = BELT_IDLE;

              if (!oven_has_piece && !new_piece_detected) {
                digitalWrite(Compressor, LOW);
              }

              finishCycleAndMaybeArmNext();
            }
            break;
        }
        break;
    }
    vTaskDelay(pdMS_TO_TICKS(20));
  }
}

void applySawSegment(uint8_t idx) {
  if (idx >= sawPatternLen) return;
  digitalWrite(Saw_Motor, sawPatternOn[idx] ? HIGH : LOW);
}

// ==============================
//     Serial Logger Task
// ==============================
void serialLoggerTask(void *pvParameters) {
  Serial.println(
    "timestamp(ms),"
    "RS_Table_vacum_position,RS_Table_belt_position,Belt_Light_Bar,RS_Table_Saw_position,"
    "RS_Vacum_Table_position,RS_Vacum_Oven_position,Oven_Light_Bar,RS_Oven_Feed_In,RS_Oven_Feed_Out,"
    "Move_Table_TO_belt,Move_Table_TO_Vacuum,Belt_Motor,Saw_Motor,Move_Vacuum_To_OvenPin,Move_Vacuum_To_TablePin,"
    "Oven_Light,Compressor,Gripper,Vacuum_Valve,Oven_DoorPin,Table_Valve,Move_Oven_inside,Move_Oven_outside"
  );

  while (true) {
    unsigned long ts = millis();
    Serial.print(ts);

    auto logPin = [](int pin) { Serial.print(","); Serial.print(digitalRead(pin)); };

    logPin(RS_Table_vacum_position);
    logPin(RS_Table_belt_position);
    logPin(Belt_Light_Bar);
    logPin(RS_Table_Saw_position);
    logPin(RS_Vacum_Table_position);
    logPin(RS_Vacum_Oven_position);
    logPin(Oven_Light_Bar);
    logPin(RS_Oven_Feed_In);
    logPin(RS_Oven_Feed_Out);

    logPin(Move_Table_TO_belt);
    logPin(Move_Table_TO_Vacuum);
    logPin(Belt_Motor);
    logPin(Saw_Motor);
    logPin(Move_Vacuum_To_OvenPin);
    logPin(Move_Vacuum_To_TablePin);
    logPin(Oven_Light);
    logPin(Compressor);
    logPin(Gripper);
    logPin(Vacuum_Valve);
    logPin(Oven_DoorPin);
    logPin(Table_Valve);
    logPin(Move_Oven_inside);
    logPin(Move_Oven_outside);

    Serial.println();
    vTaskDelay(pdMS_TO_TICKS(20));
  }
}

// ==============================
//     Serial Command Task (FIFO)
// ==============================
//
// Each newline = one queued recipe.
// Examples:
//   "no machining, cleaning, painting"
//   "basic shape, cleaning"
//   "advance shape, cleaning, painting"  -> SPECIAL: reheat 2s as NEW, then second saw 2-1-2
//   "extra shape"
//   "stop"
//
void serialCommandTask(void *pvParameters) {
  String line;
  while (true) {
    while (Serial.available()) {
      char c = (char)Serial.read();
      if (c == '\r') continue;
      if (c == '\n') {
        String cmd = line; line = "";
        cmd.trim(); cmd.toLowerCase();
        if (cmd.length() == 0) continue;

        if (cmd == "stop") {
          recipe_active = false;
          currentRecipeValid = false;
          clearQueue();
          new_piece_detected = false;
          ovenState = OV_IDLE;
          vacuumState = VAC_IDLE;
          tableState = TAB_IDLE;
          Serial.println("[OK] Stopped and queue cleared. System idle.");
          continue;
        }

        // Parse tokens
        bool tok_no_machining = false;
        bool tok_basic = false, tok_advance = false, tok_extra = false;
        bool tok_cleaning = false, tok_painting = false;

        int start = 0;
        while (start < (int)cmd.length()) {
          int comma = cmd.indexOf(',', start);
          String token = (comma == -1) ? cmd.substring(start) : cmd.substring(start, comma);
          token.trim(); token.toLowerCase();

          if (token.length()) {
            if (token == "no machining") tok_no_machining = true;
            else if (token == "basic shape")   tok_basic = true;
            else if (token == "advance shape" || token == "advanced shape") tok_advance = true;
            else if (token == "extra shape")   tok_extra = true;
            else if (token == "cleaning")      tok_cleaning = true;
            else if (token == "painting")      tok_painting = true;
          }
          if (comma == -1) break;
          start = comma + 1;
        }

        // Build recipe
        Recipe r = {};
        if (tok_no_machining) {
          r.skip_oven = true;
          r.heat_ms = 0;
        } else if (tok_basic || tok_advance || tok_extra) {
          r.skip_oven = false;
          if (tok_basic)        r.heat_ms = 5000;
          else if (tok_advance) r.heat_ms = 8000;
          else                  r.heat_ms = 10000; // extra
        } else {
          Serial.println("[WARN] Missing machining token. Use: no machining | basic shape | advance shape | extra shape");
          continue;
        }

        // Saw pattern (cleaning and/or painting)
        if (tok_cleaning && tok_painting) {
          // 2s ON, 1s OFF, 2s ON
          r.sawLen = 3;
          r.sawDur[0] = 2000; r.sawOn[0] = true;
          r.sawDur[1] = 1000; r.sawOn[1] = false;
          r.sawDur[2] = 2000; r.sawOn[2] = true;
        } else if (tok_cleaning || tok_painting) {
          r.sawLen = 1;
          r.sawDur[0] = 2000; r.sawOn[0] = true;
        } else {
          r.sawLen = 0;
        }
        for (uint8_t i = r.sawLen; i < SAW_MAX_SEGMENTS; ++i) { r.sawDur[i] = 0; r.sawOn[i] = false; }

        // SPECIAL: "advance shape + cleaning + painting" → reheat 2s after first saw (as NEW), then run second saw 2-1-2
        r.special_reheat_after_saw = (tok_advance && tok_cleaning && tok_painting);
        r.special_reheat_ms = 2000;

        // Enqueue
        if (!enqueueRecipe(r)) {
          Serial.println("[ERR] Queue full. Please wait for current pieces to finish.");
        } else {
          uint8_t count = (qHead + CMD_QUEUE_CAP - qTail) % CMD_QUEUE_CAP;
          Serial.print("[QUEUED] "); Serial.print(cmd);
          Serial.print("  | queue size: "); Serial.println(count);

          if (!recipe_active && !currentRecipeValid) armNextRecipeIfAvailable();
        }
      } else {
        line += c;
      }
    }
    vTaskDelay(pdMS_TO_TICKS(20));
  }
}

// ==============================
//     Homing / Ready
// ==============================
void Ready() {
  while (digitalRead(RS_Table_vacum_position) == LOW) {
    digitalWrite(Move_Table_TO_Vacuum, HIGH);
    digitalWrite(Move_Table_TO_belt, LOW);
    delay(10);
  }

  while (digitalRead(RS_Vacum_Table_position) == LOW) {
    digitalWrite(Move_Vacuum_To_TablePin, HIGH);
    digitalWrite(Move_Vacuum_To_OvenPin, LOW);
    delay(10);
  }

  while (digitalRead(RS_Oven_Feed_Out) == LOW) {
    digitalWrite(Move_Oven_outside, HIGH);
    delay(10);
  }

  digitalWrite(Move_Oven_outside, LOW);
  digitalWrite(Oven_DoorPin, LOW);
  door_is_open = false;

  oven_has_piece = false;
  piece_is_heated = false;
  new_piece_detected = false;
  vacuum_holding_piece = false;
  table_has_piece = false;
  vacuum_at_oven = false;
  vacuum_at_table = false;
  table_at_vacuum_pos = false;
  feeder_is_out = true;

  ovenState = OV_IDLE;
  vacuumState = VAC_IDLE;
  tableState = TAB_IDLE;

  heating_duration_ms = 1000;
  current_heating_ms = 1000;
  noInterrupts();
  sawPatternLen = 1;
  sawPatternDur[0] = 1000;
  sawPatternOn[0] = true;
  special_reheat_after_saw_active = false;
  rework_active = false;
  rework_stage = 0;
  reheat_mode_active = false;
  post_reheat_second_saw_pending = false;
  interrupts();
}
