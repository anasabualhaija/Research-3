///////////////ANAs

#include <WiFi.h>
#include <esp_wifi.h>   // for wifi_tx_info_t (IDF v5.x)
#include <esp_now.h>

/* =========================
 *  ESP-NOW MACs & Messages
 * ========================= */
uint8_t grabberMAC[6] = { 0xD0, 0xEF, 0x76, 0x58, 0x14, 0xB0 };
uint8_t hbwMAC    [6] = { 0xCC, 0x7B, 0x5C, 0xFD, 0x37, 0xE4 };

#define MSG_PIECE_READY     1
#define MSG_PIECE_PICKED    2
#define Bring_the_holder    3

typedef struct {
  uint8_t cmd;
  uint8_t slotIndex;  // 0..8 for POS1..POS9
} message_t;

/* =========================
 *  Command Queue (FIFO)
 * ========================= */
typedef enum : uint8_t {
  EXEC_CMD_RETRIEVE = 0
} exec_cmd_t;

typedef struct {
  exec_cmd_t type;
  uint8_t slotIndex;          // 0..8
} exec_job_t;

static QueueHandle_t g_cmdQueue = nullptr;     // serial RETRIEVE -> executor

// Track the life-cycle around a retrieve
static volatile bool waitingPickup[9];  // set true when we deliver to belt
static volatile bool returnReady[9];    // set true upon MSG_PIECE_PICKED

/* =========================
 *  Slot occupancy tracking
 * ========================= */
bool slotOccupied[9];

/* =========================
 *  Pin Definitions
 * ========================= */
// Reference Switches / Light Barriers
#define REF_SWITCH_HORIZONTAL    36
#define LIGHT_BARRIER_INSIDE     39
#define LIGHT_BARRIER_OUTSIDE    34
#define REF_SWITCH_VERTICAL      35

// Encoders
#define ENCODER_HORZ_IMP1        32
#define ENCODER_HORZ_IMP2        33
#define ENCODER_VERT_IMP1        25
#define ENCODER_VERT_IMP2        26

// Cantilever switches
#define REF_SWITCH_CANTILEVER_FRONT 27
#define REF_SWITCH_CANTILEVER_BACK  14

// Motor Outputs
#define MOTOR_CONVEYOR_FWD     23
#define MOTOR_CONVEYOR_BWD     22
#define MOTOR_HORZ_TO_RACK     21
#define MOTOR_HORZ_TO_CONVEYOR 19
#define MOTOR_VERT_DOWN        18
#define MOTOR_VERT_UP          4
#define MOTOR_CANTILEVER_FWD   17
#define MOTOR_CANTILEVER_BWD   16

/* =========================
 *  Globals & Encoder Table
 * ========================= */
volatile int verticalPulseCount   = 0;
volatile int horizontalPulseCount = 0;
volatile int8_t verticalMoveDirection   = 0;
volatile int8_t horizontalMoveDirection = 0;

const int8_t encoder_table[16] = {
  0, -1,  1, 0,
  1,  0,  0, -1,
 -1,  0,  0,  1,
  0,  1, -1, 0
};

/* =========================
 *  Forward Declarations
 * ========================= */
// ESP-NOW (IDF v5.x signatures)
void onDataSent(const wifi_tx_info_t *info, esp_now_send_status_t status);
void onDataRecv(const esp_now_recv_info_t *info, const uint8_t *data, int len);
void initEspNow(const uint8_t* peerMAC);

// Motion routines
void moveHorizontalToPosition(int target);
void moveVerticalToPosition(int target);
void moveCantileverTo(String dir);
void getTargetForPosition(String action, String position, int &hT, int &vT);
void homeCantilever();
void homeHorizontal();
void homeVertical();

// Tasks
void pulseCounterTask(void *pvParameters);
void motionTask(void *pvParameters);
void serialCommandTask(void *pvParameters);
void serialLoggerTask(void *pvParameters);

// Executor + helpers
void executorTask(void *pvParameters);
void doRetrieveCycle(uint8_t idx);
void doReturnEmptyToSlot(uint8_t idx);

// Core flow
void retrieveSlot(int idx);

/* =========================
 *  ESP-NOW Callbacks
 * ========================= */
void onDataSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {
  // Optional debug
  // if (info) {
  //   char macStr[18];
  //   sprintf(macStr, "%02X:%02X:%02X:%02X:%02X:%02X",
  //           info->dest_addr[0], info->dest_addr[1], info->dest_addr[2],
  //           info->dest_addr[3], info->dest_addr[4], info->dest_addr[5]);
  //   Serial.printf("ESP-NOW send to %s -> status=%d\n", macStr, (int)status);
  // }
}

void onDataRecv(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  if (len < (int)sizeof(message_t)) return;
  message_t msg;
  memcpy(&msg, data, sizeof(msg));

  // Do not allow radio to trigger retrievals
  if (msg.cmd == Bring_the_holder) {
    return;
  }

  // On MSG_PIECE_PICKED, mark return for that slot as ready
  if (msg.cmd == MSG_PIECE_PICKED) {
    uint8_t idx = msg.slotIndex;
    if (idx < 9) {
      returnReady[idx] = true;  // executor is waiting on this
    }
    return;
  }
}

/* =========================
 *  ESP-NOW Init
 * ========================= */
void initEspNow(const uint8_t* peerMAC) {
  WiFi.mode(WIFI_STA);
  if (esp_now_init() != ESP_OK) {
    return;
  }
  esp_now_register_send_cb(onDataSent);
  esp_now_register_recv_cb(onDataRecv);
  esp_now_peer_info_t peer = {};
  memcpy(peer.peer_addr, peerMAC, 6);
  peer.channel = 0;
  peer.encrypt = false;
  esp_now_add_peer(&peer);
}

/* =========================
 *  Encoder ISRs
 * ========================= */
void IRAM_ATTR handleVerticalEncoder() {
  if (verticalMoveDirection == 0) return;
  static uint8_t lastState = 0;
  uint8_t A = digitalRead(ENCODER_VERT_IMP1);
  uint8_t B = digitalRead(ENCODER_VERT_IMP2);
  uint8_t cur = (A<<1)|B;
  uint8_t comb = (lastState<<2)|cur;
  verticalPulseCount += encoder_table[comb];
  lastState = cur;
}

void IRAM_ATTR handleHorizontalEncoder() {
  if (horizontalMoveDirection == 0) return;
  static uint8_t lastState = 0;
  uint8_t A = digitalRead(ENCODER_HORZ_IMP1);
  uint8_t B = digitalRead(ENCODER_HORZ_IMP2);
  uint8_t cur = (A<<1)|B;
  if (cur != lastState) {
    uint8_t comb = (lastState<<2)|cur;
    horizontalPulseCount -= encoder_table[comb];
    lastState = cur;
  }
}

/* =========================
 *  Motion Routines
 * ========================= */
void moveVerticalToPosition(int target) {
  if (verticalPulseCount < target) {
    digitalWrite(MOTOR_VERT_DOWN, HIGH);
    digitalWrite(MOTOR_VERT_UP,   LOW);
    verticalMoveDirection = 1;
  } else if (verticalPulseCount > target) {
    digitalWrite(MOTOR_VERT_DOWN, LOW);
    digitalWrite(MOTOR_VERT_UP,   HIGH);
    verticalMoveDirection = -1;
  } else return;

  while ((verticalMoveDirection==1 && verticalPulseCount<target) ||
         (verticalMoveDirection==-1&& verticalPulseCount>target)) {
    delay(1);
  }
  digitalWrite(MOTOR_VERT_DOWN, LOW);
  digitalWrite(MOTOR_VERT_UP,   LOW);
  verticalMoveDirection = 0;
}

void moveHorizontalToPosition(int target) {
  if (horizontalPulseCount < target) {
    digitalWrite(MOTOR_HORZ_TO_RACK,     HIGH);
    digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW);
    horizontalMoveDirection = 1;
  } else if (horizontalPulseCount > target) {
    digitalWrite(MOTOR_HORZ_TO_RACK,     LOW);
    digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH);
    horizontalMoveDirection = -1;
  } else return;

  while ((horizontalMoveDirection==1 && horizontalPulseCount<target) ||
         (horizontalMoveDirection==-1&& horizontalPulseCount>target)) {
    delay(1);
  }
  digitalWrite(MOTOR_HORZ_TO_RACK,     LOW);
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW);
  horizontalMoveDirection = 0;
}

void moveCantileverTo(String dir) {
  if (dir == "IN") {
    delay(10);
    digitalWrite(MOTOR_CANTILEVER_FWD, HIGH);
    while (digitalRead(REF_SWITCH_CANTILEVER_FRONT) == LOW) delay(10);
    digitalWrite(MOTOR_CANTILEVER_FWD, LOW);
    delay(10);
  } else {
    delay(10);
    digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
    while (digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW) delay(10);
    digitalWrite(MOTOR_CANTILEVER_BWD, LOW);
    delay(10);
  }
}

/* =========================
 *  Homing
 * ========================= */
void homeCantilever() {
  while (digitalRead(REF_SWITCH_CANTILEVER_BACK) == LOW)
    digitalWrite(MOTOR_CANTILEVER_BWD, HIGH);
  digitalWrite(MOTOR_CANTILEVER_BWD, LOW);
  delay(10);
}

void homeHorizontal() {
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, HIGH);
  horizontalMoveDirection = -1;
  while (digitalRead(REF_SWITCH_HORIZONTAL) == LOW) delay(1);
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW);
  delay(100);
  horizontalPulseCount = 0; horizontalMoveDirection = 0;
  delay(10);
}

void homeVertical() {
  digitalWrite(MOTOR_VERT_UP, HIGH);
  verticalMoveDirection = -1;
  while (digitalRead(REF_SWITCH_VERTICAL) == LOW) delay(1);
  digitalWrite(MOTOR_VERT_UP, LOW);
  delay(100);
  verticalPulseCount = 0; verticalMoveDirection = 0;
  delay(10);
}

/* =========================
 *  Position Map
 * ========================= */
void getTargetForPosition(String action, String position, int &hT, int &vT) {
  if (position == "POS1") { hT=2900; vT=(action=="RETRIEVE")?500:0; }
  else if (position == "POS2") { hT=2900; vT=(action=="RETRIEVE")?1850:1500; }
  else if (position == "POS3") { hT=2900; vT=(action=="RETRIEVE")?3450:3000; }
  else if (position == "POS4") { hT=5250; vT=(action=="RETRIEVE")?500:0; }
  else if (position == "POS5") { hT=5250; vT=(action=="RETRIEVE")?1850:1500; }
  else if (position == "POS6") { hT=5250; vT=(action=="RETRIEVE")?3450:3000; }
  else if (position == "POS7") { hT=7570; vT=(action=="RETRIEVE")?500:0; }
  else if (position == "POS8") { hT=7570; vT=(action=="RETRIEVE")?1850:1500; }
  else if (position == "POS9") { hT=7570; vT=(action=="RETRIEVE")?3450:3000; }
  else if (position == "BELT")  { hT=  60; vT=2800; }
  else { hT=horizontalPulseCount; vT=verticalPulseCount; }
}

/* =========================
 *  Core flows
 * ========================= */
// Retrieve from SLOT idx (0…8), deliver piece to belt & notify grabber
void retrieveSlot(int idx) {
  String position = "POS" + String(idx + 1);
  int hT, vT;

  // 1) Move to slot & pick piece
  getTargetForPosition("RETRIEVE", position, hT, vT);
  moveHorizontalToPosition(hT);
  moveVerticalToPosition(vT);
  delay(10);
  moveCantileverTo("IN");
  delay(10);

  // 2) Clear rack
  if (idx % 3 == 0) {
    // POS1 / POS4 / POS7: instead of moving to STORE height, go fully home in Z
    homeVertical();
  } else {
    // all other slots: the old behavior stays
    getTargetForPosition("STORE", position, hT, vT);
    moveVerticalToPosition(vT);
  }
  delay(10);
  moveCantileverTo("OUT");
  delay(10);

  // 3) Deliver to belt
  getTargetForPosition("STORE", "BELT", hT, vT);
  moveHorizontalToPosition(hT);
  moveVerticalToPosition(vT);
  delay(10);
  moveCantileverTo("IN");
  delay(10);
  while (digitalRead(LIGHT_BARRIER_INSIDE) != LOW) delay(1);
  digitalWrite(MOTOR_CONVEYOR_FWD, HIGH);
  while (digitalRead(LIGHT_BARRIER_OUTSIDE) != LOW) delay(1);
  digitalWrite(MOTOR_CONVEYOR_FWD, LOW);
  delay(10);
  // Optionally leave cantilever IN
  delay(10);

  // 4) Tell grabber board the piece is ready
  message_t m = { MSG_PIECE_READY, (uint8_t)idx };
  esp_now_send(grabberMAC, (uint8_t*)&m, sizeof(m));

  waitingPickup[idx] = true;  // now awaiting MSG_PIECE_PICKED
}

void doRetrieveCycle(uint8_t idx) {
  retrieveSlot(idx);          // moves + MSG_PIECE_READY
  slotOccupied[idx] = false;  // piece removed from rack
  // returnReady[idx] will be set in onDataRecv()
}

// Execute return of EMPTY holder back to its original slot
void doReturnEmptyToSlot(uint8_t idx) {
  String position = "POS" + String(idx + 1);
  int hT, vT;

  // === 1) Go to belt and take the EMPTY holder ===
  getTargetForPosition("STORE", "BELT", hT, vT);
  moveHorizontalToPosition(hT);
  moveVerticalToPosition(vT);
  delay(10);
  // pull the holder in from belt
  digitalWrite(MOTOR_CONVEYOR_BWD, HIGH);
  while (digitalRead(LIGHT_BARRIER_INSIDE) != LOW) delay(1);
  digitalWrite(MOTOR_CONVEYOR_BWD, LOW);
  delay(10);
  moveCantileverTo("IN");
  delay(10);

  // small clearance before homing
  moveVerticalToPosition(2400);
  delay(10);
  moveCantileverTo("OUT");
  delay(10);

  // HOME all axes
  homeCantilever();
  homeVertical();
  homeHorizontal();

  // === 3) Return the empty holder to its original slot ===
  getTargetForPosition("STORE", position, hT, vT);
  moveHorizontalToPosition(hT);
  moveVerticalToPosition(vT);
  delay(10);
  moveCantileverTo("IN");
  delay(10);

  // retract to clear the slot
  getTargetForPosition("RETRIEVE", position, hT, vT);
  moveVerticalToPosition(vT);
  delay(10);
  moveCantileverTo("OUT");
  delay(10);

  waitingPickup[idx] = false;
  returnReady[idx]   = false;
}

/* =========================
 *  STRICT Sequencing Executor
 * =========================
 * For each queued RETRIEVE:
 *   1) Retrieve to belt and signal READY.
 *   2) Wait for MSG_PIECE_PICKED for that same slot.
 *   3) Return the empty holder.
 *   4) (NEW) If this was POS9, park at HOME.
 *   5) Move to the next queued command.
 */
void executorTask(void *pvParameters) {
  exec_job_t job;
  while (true) {
    // Wait for a queued RETRIEVE (blocking)
    if (xQueueReceive(g_cmdQueue, &job, portMAX_DELAY) == pdTRUE) {
      if (job.type == EXEC_CMD_RETRIEVE) {
        uint8_t idx = job.slotIndex;

        // 1) Retrieve cycle
        doRetrieveCycle(idx);

        // 2) Wait for pickup confirmation for THIS slot
        while (!returnReady[idx]) {
          vTaskDelay(pdMS_TO_TICKS(5));  // short yield
        }

        // 3) Immediately return the empty holder
        doReturnEmptyToSlot(idx);

        // 4) After finishing POS9 (slotIndex = 8), go home and stay there
        if (idx == 8) {  // <<< NEW >>>
          homeCantilever();
          homeVertical();
          homeHorizontal();
        }

        // Loop to next RETRIEVE in queue
      }
    }
  }
}

/* =========================
 *  Serial Command Parser
 * ========================= */
void serialCommandTask(void *pvParameters) {
  while (true) {
    if (!Serial.available()) { delay(50); continue; }

    String input = Serial.readStringUntil('\n');
    input.trim();
    input.toUpperCase();

    // Simple immediate cantilever jogs
    if (input == "IN" || input == "OUT") {
      moveCantileverTo(input);
      continue;
    }

    // Immediate STORE (manual store command)
    if (input.startsWith("STORE ")) {
      int i = input.indexOf(' ');
      String position = input.substring(i+1);

      int hT, vT;
      // 1) To belt
      getTargetForPosition("STORE", "BELT", hT, vT);
      moveHorizontalToPosition(hT);
      moveVerticalToPosition(vT);
      delay(10);
      moveCantileverTo("IN");
      delay(10);

      // 2) Pull in from belt
      digitalWrite(MOTOR_CONVEYOR_BWD, HIGH);
      while (digitalRead(LIGHT_BARRIER_INSIDE) != LOW) delay(1);
      digitalWrite(MOTOR_CONVEYOR_BWD, LOW);
      moveVerticalToPosition(2400);
      delay(10);
      moveCantileverTo("OUT");
      delay(10);

      // 3) To slot
      getTargetForPosition("STORE", position, hT, vT);
      moveHorizontalToPosition(hT);
      moveVerticalToPosition(vT);
      delay(10);
      moveCantileverTo("IN");
      delay(10);

      // 4) Retract
      getTargetForPosition("RETRIEVE", position, hT, vT);
      moveVerticalToPosition(vT);
      delay(10);
      moveCantileverTo("OUT");
      delay(10);
      continue;
    }

    // === Buffer RETRIEVE commands (FIFO)
    if (input.startsWith("RETRIEVE ")) {
      String pos = input.substring(9);           // e.g. "POS1"
      pos.trim();
      if (pos.startsWith("POS") && pos.length() >= 4) {
        int idx = pos.charAt(3) - '1';          // POS1→0 … POS9→8
        if (idx >= 0 && idx < 9) {
          exec_job_t job;
          job.type = EXEC_CMD_RETRIEVE;
          job.slotIndex = (uint8_t)idx;
          if (g_cmdQueue) {
            xQueueSend(g_cmdQueue, &job, 0);    // non-blocking enqueue
          }
        }
      }
      continue;
    }
  }
}

/* =========================
 *  Logger Task
 * ========================= */
void serialLoggerTask(void *pvParameters) {
  Serial.println(
    "timestamp(ms),"
    "REF_SWITCH_HORIZONTAL,LIGHT_BARRIER_INSIDE,LIGHT_BARRIER_OUTSIDE,REF_SWITCH_VERTICAL,"
    "REF_SWITCH_CANTILEVER_FRONT,REF_SWITCH_CANTILEVER_BACK,"
    "MOTOR_CONVEYOR_FWD,MOTOR_CONVEYOR_BWD,"
    "MOTOR_HORZ_TO_RACK,MOTOR_HORZ_TO_CONVEYOR,"
    "MOTOR_VERT_DOWN,MOTOR_VERT_UP,"
    "MOTOR_CANTILEVER_FWD,MOTOR_CANTILEVER_BWD"
  );

  while (true) {
    unsigned long ts = millis();
    Serial.print(ts);

    Serial.print(","); Serial.print(digitalRead(REF_SWITCH_HORIZONTAL));
    Serial.print(","); Serial.print(digitalRead(LIGHT_BARRIER_INSIDE));
    Serial.print(","); Serial.print(digitalRead(LIGHT_BARRIER_OUTSIDE));
    Serial.print(","); Serial.print(digitalRead(REF_SWITCH_VERTICAL));
    Serial.print(","); Serial.print(digitalRead(REF_SWITCH_CANTILEVER_FRONT));
    Serial.print(","); Serial.print(digitalRead(REF_SWITCH_CANTILEVER_BACK));

    Serial.print(","); Serial.print(digitalRead(MOTOR_CONVEYOR_FWD));
    Serial.print(","); Serial.print(digitalRead(MOTOR_CONVEYOR_BWD));
    Serial.print(","); Serial.print(digitalRead(MOTOR_HORZ_TO_RACK));
    Serial.print(","); Serial.print(digitalRead(MOTOR_HORZ_TO_CONVEYOR));
    Serial.print(","); Serial.print(digitalRead(MOTOR_VERT_DOWN));
    Serial.print(","); Serial.print(digitalRead(MOTOR_VERT_UP));
    Serial.print(","); Serial.print(digitalRead(MOTOR_CANTILEVER_FWD));
    Serial.print(","); Serial.println(digitalRead(MOTOR_CANTILEVER_BWD));

    vTaskDelay(pdMS_TO_TICKS(20));  // ~10 Hz
  }
}

/* =========================
 *  Setup / Loop
 * ========================= */
void setup() {
  Serial.begin(115200);
  delay(500);

  // ESP-NOW link
  initEspNow(grabberMAC);
  for (int i = 0; i < 9; i++) {
    slotOccupied[i] = true;
    waitingPickup[i] = false;
    returnReady[i]   = false;
  }

  // Pin modes
  pinMode(REF_SWITCH_HORIZONTAL,    INPUT);
  pinMode(LIGHT_BARRIER_INSIDE,     INPUT);
  pinMode(LIGHT_BARRIER_OUTSIDE,    INPUT);
  pinMode(REF_SWITCH_VERTICAL,      INPUT);
  pinMode(ENCODER_HORZ_IMP1,        INPUT);
  pinMode(ENCODER_HORZ_IMP2,        INPUT);
  pinMode(ENCODER_VERT_IMP1,        INPUT);
  pinMode(ENCODER_VERT_IMP2,        INPUT);
  pinMode(REF_SWITCH_CANTILEVER_FRONT, INPUT);
  pinMode(REF_SWITCH_CANTILEVER_BACK,  INPUT);
  pinMode(MOTOR_CONVEYOR_FWD,       OUTPUT);
  pinMode(MOTOR_CONVEYOR_BWD,       OUTPUT);
  pinMode(MOTOR_HORZ_TO_RACK,       OUTPUT);
  pinMode(MOTOR_HORZ_TO_CONVEYOR,   OUTPUT);
  pinMode(MOTOR_VERT_DOWN,          OUTPUT);
  pinMode(MOTOR_VERT_UP,            OUTPUT);
  pinMode(MOTOR_CANTILEVER_FWD,     OUTPUT);
  pinMode(MOTOR_CANTILEVER_BWD,     OUTPUT);

  // Initial outputs
  digitalWrite(MOTOR_CONVEYOR_FWD,     LOW);
  digitalWrite(MOTOR_CONVEYOR_BWD,     LOW);
  digitalWrite(MOTOR_HORZ_TO_RACK,     LOW);
  digitalWrite(MOTOR_HORZ_TO_CONVEYOR, LOW);
  digitalWrite(MOTOR_VERT_DOWN,        LOW);
  digitalWrite(MOTOR_VERT_UP,          LOW);
  digitalWrite(MOTOR_CANTILEVER_FWD,   LOW);
  digitalWrite(MOTOR_CANTILEVER_BWD,   LOW);

  // Attach interrupts
  attachInterrupt(digitalPinToInterrupt(ENCODER_VERT_IMP1),   handleVerticalEncoder,   CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_VERT_IMP2),   handleVerticalEncoder,   CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_HORZ_IMP1),   handleHorizontalEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_HORZ_IMP2),   handleHorizontalEncoder, CHANGE);

  // Create queue
  g_cmdQueue = xQueueCreate(16, sizeof(exec_job_t));     // adjust depth as needed

  // Start tasks
  xTaskCreatePinnedToCore(pulseCounterTask,  "PulseCounterTask",  2048, NULL, 1, NULL, 0);
  xTaskCreatePinnedToCore(motionTask,        "MotionTask",        4096, NULL, 1, NULL, 1);
  xTaskCreatePinnedToCore(serialCommandTask, "SerialCommandTask", 4096, NULL, 1, NULL, 1);
  xTaskCreatePinnedToCore(serialLoggerTask,  "SerialLogger",      4096, NULL, 1, NULL, 1);
  xTaskCreatePinnedToCore(executorTask,      "ExecutorTask",      8192, NULL, 2, NULL, 1);
}

void loop() {
  delay(1000);
}

/* =========================
 *  Motion task: initial homing
 * ========================= */
void motionTask(void *pvParameters) {
  delay(1000);
  homeCantilever();
  homeVertical();
  homeHorizontal();
  vTaskDelete(NULL);
}

void pulseCounterTask(void *pvParameters) {
  while (1) delay(1000);
}
