import pandas as pd
import os

# 1. Define the file path for the Grabber file
file_path = r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\comp. 1\merged data\Exp 10\ESP32_Grabber.xlsx"

# 2. Load the data
print(f"Reading file from: {file_path}")
try:
    df = pd.read_excel(file_path)
except Exception as e:
    print(f"Error reading Excel file. Trying CSV format... ({e})")
    df = pd.read_csv(file_path)

# 3. Initialize the Piece column
df['Piece'] = 0

current_piece = 0
target_pin = 'MOTOR_ROTATE_COUNTERCLOCKWISE'
target_value = 1

# 4. Iterate through the data to mark pieces
for index, row in df.iterrows():
    # Check if this row is the start of a new piece
    if row['pin name'] == target_pin and row['newstate_norm'] == target_value:
        current_piece += 1
    
    # Assign the current piece number
    if current_piece > 0:
        df.at[index, 'Piece'] = current_piece

# 5. Save the result
directory = os.path.dirname(file_path)
filename = os.path.basename(file_path)
new_filename = "Marked_" + filename
output_path = os.path.join(directory, new_filename)

df.to_excel(output_path, index=False)
print(f"Processing complete. File saved to: {output_path}")
