import pandas as pd
import os

# 1. Define the file path
file_path = r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\comp. 1\merged data\Exp 10\ESP32_HBW.xlsx"

# 2. Load the data
# Note: If your file is actually a CSV (comma separated), change read_excel to read_csv
print(f"Reading file from: {file_path}")
try:
    df = pd.read_excel(file_path)
except Exception as e:
    print(f"Error reading Excel file. Trying CSV format... ({e})")
    df = pd.read_csv(file_path)

# 3. Initialize the Piece column
df['Piece'] = 0

current_piece = 1
barrier_found = False
bwd_count_after_barrier = 0

# 4. Iterate through the data to mark pieces
for index, row in df.iterrows():
    # Stop marking if we have finished piece 9
    if current_piece > 9:
        df.at[index, 'Piece'] = 0 # Mark remaining rows as 0
        continue

    # Assign the current piece number to this row
    df.at[index, 'Piece'] = current_piece

    # Check for the "trigger" signal: LIGHT_BARRIER_OUTSIDE moves to 0
    if row['pin name'] == 'LIGHT_BARRIER_OUTSIDE' and row['newstate_norm'] == 0:
        barrier_found = True
        bwd_count_after_barrier = 0 # Reset the counter for the motor

    # If the barrier was triggered, look for the "end" signal: 
    # 2nd occurrence of MOTOR_CANTILEVER_BWD moving to 0
    if barrier_found:
        if row['pin name'] == 'MOTOR_CANTILEVER_BWD' and row['newstate_norm'] == 0:
            bwd_count_after_barrier += 1
            
            # If we find the 2nd one, this row is the last row of the current piece
            if bwd_count_after_barrier == 2:
                current_piece += 1
                barrier_found = False
                bwd_count_after_barrier = 0

# 5. Save the result
# Create a new filename for the output
directory = os.path.dirname(file_path)
filename = os.path.basename(file_path)
new_filename = "Marked_" + filename
output_path = os.path.join(directory, new_filename)

# Save to Excel (or CSV if you prefer)
df.to_excel(output_path, index=False)
print(f"Processing complete. File saved to: {output_path}")
