import pandas as pd
import os

# 1. Define the file paths
file_paths = [
    r"C:\Users\anasa\Desktop\Data Collection under work\comp. 1\merged data\Exp 10\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Marked_ESP32_ColorSorter_with_color.xlsx",
    r"C:\Users\anasa\Desktop\Data Collection under work\comp. 1\merged data\Exp 10\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Marked_ESP32_Grabber_with_movment.xlsx",
    r"C:\Users\anasa\Desktop\Data Collection under work\comp. 1\merged data\Exp 10\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Marked_ESP32_HBW_with_position.xlsx",
    r"C:\Users\anasa\Desktop\Data Collection under work\comp. 1\merged data\Exp 10\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Marked_ESP32_Oven_with_complxity_and_Surfase treatment.xlsx"
]

# List to hold the dataframes
dfs = []

# 2. Loop through each file path and read it
for path in file_paths:
    print(f"Reading: {os.path.basename(path)}")
    try:
        # Try reading as Excel
        df = pd.read_excel(path)
        dfs.append(df)
    except Exception as e_excel:
        try:
            # Fallback to CSV if Excel fails
            print(f"Excel read failed ({e_excel}), trying CSV...")
            df = pd.read_csv(path)
            dfs.append(df)
        except Exception as e_csv:
            print(f"Error reading {path}: {e_csv}")

# 3. Concatenate all dataframes into one
if dfs:
    merged_df = pd.concat(dfs, ignore_index=True)
    
    # 4. Sort by RelativeTime(ms)
    if 'RelativeTime(ms)' in merged_df.columns:
        merged_df = merged_df.sort_values(by='RelativeTime(ms)')
        print("Data sorted by RelativeTime(ms).")
    else:
        print("Warning: 'RelativeTime(ms)' column not found. Data might not be sorted correctly.")

    # ---------------------------------------------------------
    # 5. NEW STEP: Add 'movement number' column
    # ---------------------------------------------------------
    if 'pin name' in merged_df.columns and 'newstate_norm' in merged_df.columns:
        # Group by pin and state, then count occurrences (cumulatively)
        # Adding 1 so the count starts at 1 instead of 0
        merged_df['movement number'] = merged_df.groupby(['station','pin name', 'newstate_norm']).cumcount() + 1
        print("Successfully added 'movement number' column.")
    else:
        print("Warning: Could not create 'movement number'. Check if 'pin name' and 'newstate_norm' columns exist.")

    # 6. Save the merged file
    output_dir = os.path.dirname(file_paths[0])
    output_path = os.path.join(output_dir, "Merged_All_Stations_with_all_parameters.xlsx")
    
    try:
        merged_df.to_excel(output_path, index=False)
        print(f"Successfully merged {len(dfs)} files.")
        print(f"Saved to: {output_path}")
    except PermissionError:
        print(f"Error: Permission denied. Please close '{os.path.basename(output_path)}' if it is open.")

else:
    print("No data found to merge.")
