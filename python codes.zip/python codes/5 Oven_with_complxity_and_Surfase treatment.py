import pandas as pd

# Define the file path for the Oven data
file_path = r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\comp. 1\merged data\Exp 10\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Marked_ESP32_Oven.xlsx"

# Load the Excel file
df = pd.read_excel(file_path)

# 1. Define Complexity Mapping
complexity_map = {
    1: "No machining",
    2: "Basic Shape",
    3: "No machining",
    4: "Advance Shape",
    5: "Advance Shape",
    6: "Advance Shape",
    7: "Extra Shape",
    8: "Basic Shape",
    9: "No machining"
}

# 2. Define Surface Treatment Mapping
surface_map = {
    1: "Cleaning, and painting",
    2: "Only cleaning",
    3: "Cleaning, and painting",
    4: "Cleaning, and painting",
    5: "Only cleaning",
    6: "Only cleaning",
    7: "Cleaning, and painting",
    8: "Cleaning, and painting",
    9: "Cleaning, and painting",
}

# Apply the mappings to create new columns
df['complexity'] = df['Piece'].map(complexity_map)
df['surface treatment'] = df['Piece'].map(surface_map)

# Define output path (saving as a new file to be safe)
output_path = r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\comp. 1\merged data\Exp 10\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Marked_ESP32_Oven_with_complxity_and_Surfase treatment.xlsx"

# Save to Excel
df.to_excel(output_path, index=False)

print(f"File updated successfully! Saved at: {output_path}")
