import pandas as pd
import os

# 1. Define the path to your original CSV file
file_path = r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\comp. 1\merged data\factory_data_From_HBW_To_Sorter_10_filtered.csv"

# 2. Load the dataset
df = pd.read_csv(file_path)

# 3. Get the list of unique stations
stations = df['station'].unique()

# Get the directory of the original file to save outputs in the same folder
output_directory = os.path.dirname(file_path)

print(f"Processing data from: {file_path}")

# 4. Iterate through each station, process data, and save
for station in stations:
    # Filter the dataframe for the current station
    station_df = df[df['station'] == station].copy()  # .copy() prevents warnings when modifying
    
    # --- MERGED LOGIC: Invert the 'pin status' column ---
    # This changes 0 to 1 and 1 to 0
    station_df['pin status'] = 1 - station_df['pin status']
    # ----------------------------------------------------
    
    # Create the full output path (e.g., C:\Users\...\ESP32_HBW.xlsx)
    output_filename = os.path.join(output_directory, f"{station}.xlsx")
    
    # Save to Excel
    station_df.to_excel(output_filename, index=False)
    
    print(f"Created file (with inverted pin status): {output_filename}")

print("All files have been split and updated successfully.")
