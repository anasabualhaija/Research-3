import pandas as pd

# Define the file path
file_path = r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\comp. 1\merged data\Exp 10\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Marked_ESP32_ColorSorter.xlsx"

# Load the Excel file
# Note: openpyxl engine is used for .xlsx files
df = pd.read_excel(file_path)

# Define the mapping logic for the 'position' column
# This maps the value in the 'Piece' column to the 'pos X' string
mapping = {
    1: 'red',
    2: 'white',
    3: 'red',
    4: 'red',
    5: 'white',
    6: 'white',
    7: 'blue',
    8: 'blue',
    9: 'blue'
}

# Create the new 'position' column
# It looks at the 'Piece' column and applies the mapping defined above
df['Color'] = df['Piece'].map(mapping)

# Save the updated file
# You can overwrite the original or save as a new version
output_path = r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\comp. 1\merged data\Exp 10\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Marked_ESP32_ColorSorter_with_color.xlsx"

df.to_excel(output_path, index=False)

print(f"Process complete. The updated file is saved at: {output_path}")
