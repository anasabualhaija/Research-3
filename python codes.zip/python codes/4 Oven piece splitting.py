import pandas as pd
import os

# 1. Define the file path
file_path = r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\comp. 1\merged data\Exp 10\ESP32_Oven.xlsx"

# 2. Load the data
print(f"Reading file from: {file_path}")
try:
    df = pd.read_excel(file_path)
except Exception as e:
    print(f"Error reading Excel file. Trying CSV format... ({e})")
    df = pd.read_csv(file_path)

# 3. Initialize the Piece column
df['Piece'] = 0

current_piece = 1
target_pin = "Belt_Motor"
target_status = 0

# 4. Iterate through the data to mark pieces
for index, row in df.iterrows():
    
    # Assign the current piece number to this row FIRST
    if current_piece <= 9:
        df.at[index, 'Piece'] = current_piece
    else:
        # If we are past piece 9, mark as 0
        df.at[index, 'Piece'] = 0

    # THEN check if this row marks the end of the piece
    if row['pin name'] == target_pin and row['newstate_norm'] == target_status:
        # Increment for the NEXT row
        current_piece += 1

# 5. Save the result
directory = os.path.dirname(file_path)
filename = os.path.basename(file_path)
new_filename = "Marked_" + filename
output_path = os.path.join(directory, new_filename)

try:
    df.to_excel(output_path, index=False)
    print(f"Processing complete. File saved to: {output_path}")
except PermissionError:
    print(f"Error: Permission denied. Please close '{filename}' and try again.")
