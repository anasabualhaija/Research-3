import os
import re
import pandas as pd
from pathlib import Path
from functools import reduce

# =======================
# USER INPUT: file paths
# =======================
FILES = [
    r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\factory_data_From_HBW_To_Sorter_1.csv",
    r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\factory_data_From_HBW_To_Sorter_2.csv",
    r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\factory_data_From_HBW_To_Sorter_3.csv",
    r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\factory_data_From_HBW_To_Sorter_4.csv",
    r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\factory_data_From_HBW_To_Sorter_5.csv",
    r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\factory_data_From_HBW_To_Sorter_6.csv",
    r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\factory_data_From_HBW_To_Sorter_7.csv",
    r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\factory_data_From_HBW_To_Sorter_8.csv",
    r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\factory_data_From_HBW_To_Sorter_9.csv",
    r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\factory_data_From_HBW_To_Sorter_10.csv",
]

# =======================
# OUTPUT FOLDER (fixed)
# =======================
OUTPUT_DIR = r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\comp. 1"

# Subfolders produced by this script
MERGED_SUBFOLDER = "merged data"   # Phase 2 output
FINAL_SUBFOLDER  = "final"         # Phase 3 output

# =======================
# CONFIG
# =======================
# Keep 0 if you want to keep tail rows. If >0, drops last N rows in Phase 1 only.
TAIL_EXCLUDE_ROWS = 61
EXCLUDE_PINS = {"VALVE_PUSH_COUNT", "STOP_FLAG"}  # fully exclude from outputs
DROP_DURATION_LE_MS = 20                          # drop rows whose duration <= this (in ms)

# Combined comparison (file name kept the same)
WRITE_COMPARISON_XLSX = True
OUTPUT_XLSX = "comparison_1_to_10.xlsx"
OUTPUT_CSV  = "comparison_1_to_10.csv"

# Try to detect openpyxl availability
_HAS_OPENPYXL = False
try:
    import openpyxl  # noqa: F401
    _HAS_OPENPYXL = True
except Exception:
    _HAS_OPENPYXL = False

# If your CSV columns have different names, the auto-detection below should still find them.
POSSIBLE_COLS = {
    "pin": ["pin", "pin name", "pin_name", "Pin"],
    "station": ["station", "module", "device", "Station"],
    "newstate": ["newstate", "state", "value", "newstate_norm", "NewState"],
    "duration": ["duration(ms)", "duration", "dur(ms)", "time(ms)", "elapsed(ms)", "Duration(ms)"],
    # Added RelativeTime detection
    "relativetime": ["relativetime(ms)", "relative_time", "relativetime", "time", "RelativeTime(ms)"],
}

# =======================
# Helpers
# =======================

def find_col(df, keys):
    cols_l = {c.strip().lower(): c for c in df.columns}
    # exact match (lower)
    for key in keys:
        if key in cols_l:
            return cols_l[key]
    # contains match
    for lc, orig in cols_l.items():
        for key in keys:
            if key in lc:
                return orig
    raise KeyError(f"Could not find any of columns: {keys} in: {list(df.columns)}")

def normalize_newstate(x):
    """
    Map NewState to 0/1 robustly; otherwise keep a readable string.
    (No inversion here; stays faithful to source rows.)
    """
    if pd.isna(x):
        return None
    s = str(x).strip().lower()
    # numeric first
    try:
        f = float(s)
        if f == 0:
            return 0
        if f == 1:
            return 1
    except ValueError:
        pass
    # common strings
    high_vals = {"high", "on", "true", "1", "up"}
    low_vals  = {"low", "off", "false", "0", "down"}
    if s in high_vals:
        return 1
    if s in low_vals:
        return 0
    # unknown -> keep original as string
    return str(x)

def invert01(x):
    """Invert only exact 0/1 to 1/0; leave anything else unchanged."""
    if x == 0:
        return 1
    if x == 1:
        return 0
    return x

def _to_numeric_ms(series):
    """
    Robust numeric conversion for duration-like columns.
    - Tries pd.to_numeric first.
    - If many NaNs remain, tries to extract the first floating number from strings.
    """
    s = pd.to_numeric(series, errors="coerce")
    if s.isna().mean() <= 0.5:
        return s
    extracted = series.astype(str).str.extract(r'([-+]?\d*\.?\d+)')[0]
    s2 = pd.to_numeric(extracted, errors="coerce")
    return s2

def extract_run_index_from_filename(path_like: str) -> int:
    """
    Extract the numeric run index from a file name like:
    'factory_data_From_HBW_To_Sorter_8_filtered.csv' → 8
    Returns -1 if not found (so such files sort last).
    """
    name = os.path.basename(path_like)
    m = re.search(r'_To_Sorter_(\d+)', name)
    if not m:
        m = re.search(r'(\d+)', name)
    return int(m.group(1)) if m else -1

# =======================
# Phase 1: Clean & export
# =======================

def load_and_prepare_single(path, keep_order=True):
    """
    Load ONE file, apply:
      - Tail exclusion (last N rows) if TAIL_EXCLUDE_ROWS > 0
      - Exclude pins in EXCLUDE_PINS
      - Drop rows with duration <= DROP_DURATION_LE_MS
    keep_order=True preserves the original row order.
    Returns a DataFrame with original columns + standardized helpers.
    """
    df = pd.read_csv(path)

    # Tail exclude (optional)
    if TAIL_EXCLUDE_ROWS > 0 and len(df) > TAIL_EXCLUDE_ROWS:
        df = df.iloc[:-TAIL_EXCLUDE_ROWS].copy()

    # Detect columns
    pin_col      = find_col(df, POSSIBLE_COLS["pin"])
    newstate_col = find_col(df, POSSIBLE_COLS["newstate"])
    duration_col = find_col(df, POSSIBLE_COLS["duration"])
    
    # Try detecting Station and RelativeTime, handle gracefully if missing (though usually present)
    try:
        station_col = find_col(df, POSSIBLE_COLS["station"])
    except KeyError:
        station_col = None

    try:
        rel_time_col = find_col(df, POSSIBLE_COLS["relativetime"])
    except KeyError:
        rel_time_col = None

    # Standardize helper columns (do NOT sort; we preserve index order)
    df["_pin"] = df[pin_col].astype(str).str.strip()
    df["_station"] = df[station_col].astype(str).str.strip() if station_col else "Unknown"
    df["_newstate_norm"] = df[newstate_col].map(normalize_newstate)
    df["_duration"] = _to_numeric_ms(df[duration_col])
    
    # Preserve RelativeTime if found
    if rel_time_col:
        df["_relativetime"] = df[rel_time_col]
    else:
        df["_relativetime"] = 0  # fallback

    # Exclude pins
    if EXCLUDE_PINS:
        df = df[~df["_pin"].isin(EXCLUDE_PINS)].copy()

    # Drop rows with duration <= threshold
    df = df[df["_duration"].notna()].copy()
    df = df[df["_duration"] > DROP_DURATION_LE_MS].copy()

    # Preserve original input order (index)
    if keep_order:
        df = df.sort_index(kind="stable")

    # A compact, user-friendly view (NO inversion of status)
    cleaned_display = df.copy()
    cleaned_display["pin status"] = df["_newstate_norm"]

    # Select columns for output
    out_cols = ["_station", "_relativetime", "_pin", "_newstate_norm", "_duration", "pin status"]
    
    return df, cleaned_display[out_cols]

def phase1_clean_and_save(file_paths, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    saved = []
    for idx, fp in enumerate(file_paths, start=1):
        try:
            _, display_df = load_and_prepare_single(fp, keep_order=True)
            base_name = Path(fp).stem  # e.g., factory_data_From_HBW_To_Sorter_8
            out_name = f"{base_name}_filtered.csv"
            out_path = os.path.join(out_dir, out_name)
            
            display_df.rename(columns={
                "_station": "station",
                "_relativetime": "RelativeTime(ms)",
                "_pin": "pin name",
                "_newstate_norm": "newstate_norm",
                "_duration": "duration(ms)"
            }).to_csv(out_path, index=False)
            
            print(f"[OK] Phase 1 saved cleaned file #{idx}: {out_path}")
            saved.append(out_path)
        except Exception as e:
            print(f"[ERROR] Phase 1 file #{idx} ({fp}): {e}")
    return saved

# =======================
# Phase 2: Merge segments
# =======================

def merge_pin_segments(df):
    """
    Merge segments per pin/state except for Pin == 'COLOR_CODE'.
    Input df can have any of the recognized column names.
    """
    # Resolve column names in this df
    pin_col      = find_col(df, POSSIBLE_COLS["pin"])
    state_col    = find_col(df, POSSIBLE_COLS["newstate"])
    duration_col = find_col(df, POSSIBLE_COLS["duration"])
    # Note: RelativeTime(ms) is present in 'df' (from Phase 1), and will be 
    # preserved in the 'leader' row of any merged segment automatically.

    df_work = df.copy()
    pin_active = {}
    rows_to_drop = []

    for idx, row in df_work.iterrows():
        pin_val = str(row[pin_col])
        state_val = row[state_col]
        dur_val = row[duration_col]

        # skip merging for COLOR_CODE entirely
        if pin_val == "COLOR_CODE":
            continue

        if pin_val not in pin_active:
            # start new segment for this pin
            pin_active[pin_val] = {
                "state": state_val,
                "leader_idx": idx,
                "total_duration": dur_val,
            }
        else:
            current_state = pin_active[pin_val]["state"]
            leader_idx = pin_active[pin_val]["leader_idx"]

            if state_val == current_state:
                # same state → merge
                pin_active[pin_val]["total_duration"] += dur_val
                rows_to_drop.append(idx)
            else:
                # state changed → close old segment and start new
                df_work.at[leader_idx, duration_col] = pin_active[pin_val]["total_duration"]
                pin_active[pin_val] = {
                    "state": state_val,
                    "leader_idx": idx,
                    "total_duration": dur_val,
                }

    # finalize open segments
    for pin_val, seginfo in pin_active.items():
        if pin_val != "COLOR_CODE":
            leader_idx = seginfo["leader_idx"]
            df_work.at[leader_idx, duration_col] = seginfo["total_duration"]

    # drop absorbed rows
    df_merged = df_work.drop(index=rows_to_drop).reset_index(drop=True)
    return df_merged

def phase2_merge_cleaned_files(cleaned_files, out_dir, merged_subfolder):
    # Write merged outputs into OUTPUT_DIR/<merged_subfolder> with SAME filenames
    merged_dir = os.path.join(out_dir, merged_subfolder)
    os.makedirs(merged_dir, exist_ok=True)

    merged_paths = []
    for in_path in cleaned_files:
        try:
            print(f"Merging segments (excluding COLOR_CODE) in: {in_path}")
            df = pd.read_csv(in_path)
            merged_df = merge_pin_segments(df)
            out_path = os.path.join(merged_dir, os.path.basename(in_path))
            merged_df.to_csv(out_path, index=False)
            merged_paths.append(out_path)
            print(f"  Saved merged file: {out_path}")
            print(f"  Original rows: {len(df)}  → After merge: {len(merged_df)}")
        except Exception as e:
            print(f"[ERROR] Phase 2 merging failed for {in_path}: {e}")

    return merged_paths

# =======================
# Phase 3: Comparison from merged (FINAL)
# =======================

def build_multi_comparison(file_paths):
    """
    Build a comparison table across files, aligning by
    (station, pin, normalized newstate, occurrence index).

    IMPORTANT:
    - Uses normalized state as-is for grouping/occurrence alignment.
    - Sets the *display* 'pin status' column to the inverted 0/1 (0→1, 1→0).
    """
    prepared = []
    for idx, p in enumerate(file_paths, start=1):
        df = pd.read_csv(p)

        # resolve columns
        try:
            station_col = find_col(df, POSSIBLE_COLS["station"])
        except KeyError:
            station_col = None  # allowed

        pin_col      = find_col(df, POSSIBLE_COLS["pin"])
        newstate_col = find_col(df, POSSIBLE_COLS["newstate"])
        duration_col = find_col(df, POSSIBLE_COLS["duration"])

        # canonical helper names
        tmp = pd.DataFrame({
            "_station": df[station_col].astype(str).str.strip() if station_col else "Unknown",
            "_pin": df[pin_col].astype(str).str.strip(),
            "_newstate_norm": df[newstate_col].map(normalize_newstate),
            "_duration": _to_numeric_ms(df[duration_col]),
        })

        # Add occurrence within each group to align repeats across runs
        tmp["_occ"] = tmp.groupby(["_station", "_pin", "_newstate_norm"]).cumcount()

        # Column name must be "duration file <RUN_INDEX>" using the number in filename
        run_index = extract_run_index_from_filename(p)
        dur_col = f"duration file {run_index if run_index != -1 else idx}"

        tmp = tmp.rename(columns={"_duration": dur_col})
        prepared.append(tmp[["_station", "_pin", "_newstate_norm", "_occ", dur_col]])

    if not prepared:
        return pd.DataFrame()

    def merge_two(a, b):
        return a.merge(b, on=["_station", "_pin", "_newstate_norm", "_occ"], how="outer")

    merged = reduce(merge_two, prepared)

    # FINAL requirement: invert pin status only in this final output sheet
    merged["pin status"] = merged["_newstate_norm"].map(invert01)

    # Order the duration columns by their numeric file index
    def duration_key(c):
        m = re.search(r'duration file (\d+)', c)
        return int(m.group(1)) if m else 10**9

    duration_cols = sorted(
        [c for c in merged.columns if c.startswith("duration file ")],
        key=duration_key
    )

    out_df = merged.rename(columns={
        "_station": "station",
        "_pin": "pin name",
    })[["station", "pin name", "pin status"] + duration_cols].copy()

    return out_df

def phase3_compare_from_merged(merged_paths, out_dir, final_subfolder):
    """
    Build the comparison from merged files.
    Save to OUTPUT_DIR/final/comparison_1_to_10.(xlsx|csv).

    Ensures:
    - "duration file N" columns map to run N by sorting paths by their run index.
    - 'pin status' is inverted (0↔1) only here.
    """
    final_dir = os.path.join(out_dir, final_subfolder)
    os.makedirs(final_dir, exist_ok=True)

    # Sort merged paths by run index extracted from filename to keep mapping stable
    merged_paths_sorted = sorted(merged_paths, key=extract_run_index_from_filename)

    comp_df = build_multi_comparison(merged_paths_sorted)
    if comp_df.empty:
        print("[INFO] Phase 3: comparison is empty after processing merged files.")
        return None

    if WRITE_COMPARISON_XLSX and _HAS_OPENPYXL:
        out_xlsx = os.path.join(final_dir, OUTPUT_XLSX)
        with pd.ExcelWriter(out_xlsx, engine="openpyxl") as writer:
            comp_df.to_excel(writer, index=False, sheet_name="comp_all")
        print(f"[OK] Phase 3 saved comparison Excel: {out_xlsx}")
        return out_xlsx
    else:
        out_csv = os.path.join(final_dir, OUTPUT_CSV)
        comp_df.to_csv(out_csv, index=False)
        print(f"[OK] Phase 3 saved comparison CSV: {out_csv}")
        if WRITE_COMPARISON_XLSX and not _HAS_OPENPYXL:
            print("  (Install Excel support with:  py -m pip install --user openpyxl )")
        return out_csv

# =======================
# Main
# =======================

def main():
    if not FILES:
        print("No input files provided.")
        return

    # Phase 1
    print("=== Phase 1: Cleaning & exporting filtered files ===")
    cleaned_paths = phase1_clean_and_save(FILES, OUTPUT_DIR)

    # Phase 2
    print("\n=== Phase 2: Merging segments into 'merged data' ===")
    merged_paths = phase2_merge_cleaned_files(cleaned_paths, OUTPUT_DIR, MERGED_SUBFOLDER)

    # Phase 3
    print("\n=== Phase 3: Building comparison from merged files into 'final' ===")
    comparison_path = phase3_compare_from_merged(merged_paths, OUTPUT_DIR, FINAL_SUBFOLDER)

    # Summary
    print("\n=== Summary ===")
    print(f"Phase 1 cleaned outputs: {len(cleaned_paths)}")
    for p in cleaned_paths:
        print(f" - {p}")
    print(f"Merged outputs saved in: {os.path.join(OUTPUT_DIR, MERGED_SUBFOLDER)}")
    if comparison_path:
        print(f"Final comparison saved: {comparison_path}")
    print(f"Base output directory: {OUTPUT_DIR}")

if __name__ == "__main__":
    main()
