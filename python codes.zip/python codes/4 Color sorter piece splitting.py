import pandas as pd
import os

# 1. Define the file path
file_path = r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\comp. 1\merged data\Exp 10\ESP32_ColorSorter.xlsx"

# 2. Load the data
print(f"Reading file from: {file_path}")
try:
    df = pd.read_excel(file_path)
except Exception as e:
    print(f"Error reading Excel file. Trying CSV format... ({e})")
    df = pd.read_csv(file_path)

# 3. Filter out unwanted rows
unwanted_pins = [ 'SENSOR_Q1', 'SENSOR_Q2', 'SENSOR_Q3']
# Keep only rows that are NOT in the unwanted list
df = df[~df['pin name'].isin(unwanted_pins)].copy()

# 4. Initialize the Piece column
df['Piece'] = 0

piece_counter = 0
target_pin = 'BELT_MOTOR'
target_status = 1

# 5. Iterate and mark pieces
for index, row in df.iterrows():
    # Check for trigger: BELT_MOTOR turns to 1
    if row['pin name'] == target_pin and row['newstate_norm'] == target_status:
        piece_counter += 1
    
    # Assign piece number (cap at 9)
    if piece_counter <= 9 and piece_counter > 0:
        df.at[index, 'Piece'] = piece_counter
    else:
        df.at[index, 'Piece'] = 0

# 6. Save the result
directory = os.path.dirname(file_path)
filename = os.path.basename(file_path)
new_filename = "Marked_" + filename
output_path = os.path.join(directory, new_filename)

try:
    df.to_excel(output_path, index=False)
    print(f"Processing complete. File saved to: {output_path}")
except PermissionError:
    print(f"Error: Permission denied. Please close '{filename}' and try again.")
