import pandas as pd

# Define the file path
file_path = r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\comp. 1\merged data\Exp 10\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Marked_ESP32_HBW.xlsx"

# Load the Excel file
# Note: openpyxl engine is used for .xlsx files
df = pd.read_excel(file_path)

# Define the mapping logic for the 'position' column
# This maps the value in the 'Piece' column to the 'pos X' string
mapping = {
    1: 'pos 2',
    2: 'pos 1',
    3: 'pos 5',
    4: 'pos 8',
    5: 'pos 4',
    6: 'pos 7',
    7: 'pos 3',
    8: 'pos 6',
    9: 'pos 9'
}

# Create the new 'position' column
# It looks at the 'Piece' column and applies the mapping defined above
df['position'] = df['Piece'].map(mapping)

# Save the updated file
# You can overwrite the original or save as a new version
output_path = r"C:\Users\anasa\OneDrive\Desktop\Data Collection under work\comp. 1\merged data\Exp 10\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Marked_ESP32_HBW_with_position.xlsx"

df.to_excel(output_path, index=False)

print(f"Process complete. The updated file is saved at: {output_path}")
