import os
import csv
import time
import queue
import threading
import serial
import webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
import json
import uuid
from datetime import datetime
import pandas as pd
import ctypes
from collections import defaultdict
from openpyxl import Workbook, load_workbook

# =======================
# CONFIGURATION
# =======================
STATIONS = {
    'ESP32_HBW': {
        'port': 'COM6',
        'send_command': False,                # queue will send commands
        'trigger_pin': 'MOTOR_HORZ_TO_RACK', # HBW provides the trigger for global t=0
        'command_delay_s': 2.0,
    },
    'ESP32_Grabber': {
        'port': 'COM4',
        'send_command': False,
    },
    'ESP32_Oven': {
        'port': 'COM3',
        'send_command': False,
    },
    'ESP32_ColorSorter': {
        'port': 'COM5',
        'send_command': False,
    }
}

BAUDRATE = 115200
OUTPUT_FILE = r'C:\Users\anasa\Desktop\Data Collection under work\monitor and test exp.csv'
REF_FILE_PATH = r"C:\Users\anasa\Desktop\Data Collection under work\Final_Results_with_Avg_and_Std.xlsx"
DURATION_ERROR_FILE = os.path.join(os.path.dirname(OUTPUT_FILE), "duration error.xlsx")

VALVE_PUSH_COUNT_COL = "VALVE_PUSH_COUNT"
STOP_FLAG_COL = "STOP_FLAG"

QUANTIZE_10MS = True
SER_TIMEOUT_S = 0.01
REALTIME_FLUSH_EVERY_ROW = True
REALTIME_FSYNC = False
DEBUG = False
TRIGGER_WARN_AFTER_S = 5.0

SNAP_AFTER_9TH_PUSH_DELAY_MS = 20000
STOP_DELAY_AFTER_9TH_PUSH_MS = 21000

DASHBOARD_PORT = 8765

# COLOR_CODE special handling
COLOR_CODE_PIN = "COLOR_CODE"
COLOR_CODE_VALUES = {0.1, 0.2, 0.3}

MIN_VALID_STATE_MS = 30

# =======================
# GLOBALS
# =======================
process_delay_offset_ms = 0
process_delay_lock = threading.Lock()

global_dev_zero_ms = None
host_start_ns = None

station_offsets_ms = {}
station_offsets_lock = threading.Lock()

stop_event = threading.Event()
stop_time_global_ms = None
pending_stop_time_ms = None
pending_snapshot_time_ms = None
stop_lock = threading.Lock()

event_queue = queue.SimpleQueue()
confirmed_counts_lock = threading.Lock()
confirmed_movement_counts = defaultdict(int)   # (station, pin, state) -> count
confirmed_color_seq_counter = defaultdict(int) # (station, pin) -> sequence count

logger_refs_lock = threading.Lock()
logger_refs = {
    'ESP32_HBW': None,
    'ESP32_Oven': None
}

order_state_lock = threading.Lock()
emptied_positions = set()
position_colors = {}
position_colors_lock = threading.Lock()

AUTO_LOAD_PRESET = True

PRESET_SELECTIONS = {
    "Pos1": "white",
    "Pos2": "red",
    "Pos3": "blue",
    "Pos4": "white",
    "Pos5": "red",
    "Pos6": "blue",
    "Pos7": "white",
    "Pos8": "red",
    "Pos9": "blue",
}

PRESET_QUEUE = [
    {"pos": "Pos2", "machining": "NO machining", "post_ops": ["Cleaning", "Painting"]},
    {"pos": "Pos1", "machining": "Basic shape", "post_ops": ["Cleaning"]},
    {"pos": "Pos5", "machining": "NO machining", "post_ops": ["Cleaning", "Painting"]},
    {"pos": "Pos8", "machining": "Advance shape", "post_ops": ["Cleaning", "Painting"]},
    {"pos": "Pos4", "machining": "Advance shape", "post_ops": ["Cleaning"]},
    {"pos": "Pos7", "machining": "Advance shape", "post_ops": ["Cleaning"]},
    {"pos": "Pos3", "machining": "Extra shape", "post_ops": ["Cleaning", "Painting"]},
    {"pos": "Pos6", "machining": "Basic shape", "post_ops": ["Cleaning", "Painting"]},
    {"pos": "Pos9", "machining": "NO machining", "post_ops": ["Cleaning", "Painting"]},
]

queue_lock = threading.Lock()
queue_cv = threading.Condition(queue_lock)
order_queue = []
runner_should_run = False


def now_iso():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# =======================
# HELPERS
# =======================
def is_high_bytes(vb: bytes) -> bool:
    v = vb.strip().upper()
    return v in {b"1", b"HIGH", b"ON", b"TRUE"}


def q10(x_ms: float) -> int:
    if not QUANTIZE_10MS:
        return int(round(x_ms))
    return int(round(x_ms / 10.0) * 10)


def normalize_state_for_pin(pin, s):
    pin = str(pin).strip()
    raw = str(s).strip().upper()

    if pin == COLOR_CODE_PIN:
        try:
            return round(float(str(s).strip()), 1)
        except Exception:
            return None

    if raw in ('1', 'HIGH', 'ON', 'TRUE', '1.0'):
        return 1
    return 0


# =======================
# CSV WRITER THREAD
# =======================
class CSVWriterThread(threading.Thread):
    def _open_duration_error_file(self):
        try:
            os.makedirs(os.path.dirname(self.duration_error_file), exist_ok=True)

            if os.path.exists(self.duration_error_file):
                self.duration_wb = load_workbook(self.duration_error_file)
                self.duration_ws = self.duration_wb.active
            else:
                self.duration_wb = Workbook()
                self.duration_ws = self.duration_wb.active
                self.duration_ws.title = "Duration Errors"
                self.duration_ws.append([
                    "Time",
                    "Station",
                    "RelativeTime(ms)",
                    "Pin",
                    "State",
                    "Movement Number",
                    "Actual Duration(ms)",
                    "Limit(ms)",
                    "Reference Avg(ms)",
                    "Reference Std(ms)"
                ])
                self.duration_wb.save(self.duration_error_file)
        except Exception as e:
            print(f"[DURATION LOG] Failed to open/create duration error file: {e}")
            self.duration_wb = None
            self.duration_ws = None


    def _log_duration_error(self, station, relative_time_ms, pin, state, movement_num, actual_duration, limit_ms, ref_avg, ref_std):
        try:
            with self.duration_error_lock:
                if self.duration_wb is None or self.duration_ws is None:
                    self._open_duration_error_file()
                if self.duration_ws is None:
                    return

                self.duration_ws.append([
                    now_iso(),
                    station,
                    relative_time_ms,
                    pin,
                    state,
                    movement_num,
                    actual_duration,
                    round(limit_ms, 2),
                    ref_avg,
                    ref_std
                ])
                self.duration_wb.save(self.duration_error_file)
        except Exception as e:
            print(f"[DURATION LOG] Failed to write duration error: {e}")
    def _stop_program_on_error(self, msg, current_time_ms=None):
            global stop_time_global_ms, runner_should_run

            with stop_lock:
                if stop_time_global_ms is None and current_time_ms is not None:
                    stop_time_global_ms = q10(current_time_ms)

            with queue_cv:
                runner_should_run = False
                queue_cv.notify_all()

            self._show_popup(msg + "\n\nPROGRAM STOPPED AT FIRST ERROR")
            stop_event.set()

    def __init__(self, path: str, stop_evt: threading.Event):
        super().__init__(daemon=True)
        self.path = path
        self.stop_evt = stop_evt
        self.f = None
        self.writer = None

        self.duration_error_file = DURATION_ERROR_FILE
        self.duration_error_lock = threading.Lock()
        self.duration_wb = None
        self.duration_ws = None
        self._open_duration_error_file()

        self.movement_counts = defaultdict(int)       # for non-COLOR_CODE pins: (station, pin, state) -> count
        self.color_seq_counter = defaultdict(int)     # for COLOR_CODE: (station, pin) -> sequence count
        self.ref_data = {}                            # (station, pin, state, mov_num) -> ref tuple
        self.color_ref_sequence = defaultdict(list)   # (station, COLOR_CODE) -> ordered list by movement number
        self._load_reference_data()
        

    def _load_reference_data(self):
        try:
            print(f"[MONITOR] Loading reference data from: {REF_FILE_PATH}")
            if not os.path.exists(REF_FILE_PATH):
                print(f"[MONITOR] ERROR: Reference file not found at {REF_FILE_PATH}")
                return

            if REF_FILE_PATH.endswith('.csv'):
                df = pd.read_csv(REF_FILE_PATH)
            else:
                df = pd.read_excel(REF_FILE_PATH)

            for _, row in df.iterrows():
                try:
                    station = str(row['station']).strip()
                    pin = str(row['pin name']).strip()
                    state = normalize_state_for_pin(pin, row['newstate_norm'])
                    if state is None:
                        continue

                    mov_num = int(row['movement number'])
                    avg_dur = float(row['duration(ms)'])
                    std_dur = float(row['duration(ms)_std'])
                    avg_rel = float(row['RelativeTime(ms)'])
                    std_rel = float(row['RelativeTime(ms)_std'])

                    self.ref_data[(station, pin, state, mov_num)] = (avg_dur, std_dur, avg_rel, std_rel)

                    if pin == COLOR_CODE_PIN:
                        self.color_ref_sequence[(station, pin)].append({
                            "state": state,
                            "mov_num": mov_num,
                            "avg_dur": avg_dur,
                            "std_dur": std_dur,
                            "avg_rel": avg_rel,
                            "std_rel": std_rel,
                        })
                except Exception:
                    continue

            for key in self.color_ref_sequence:
                self.color_ref_sequence[key].sort(key=lambda x: x["mov_num"])

            print(f"[MONITOR] Loaded {len(self.ref_data)} reference rules.")

        except Exception as e:
            print(f"[MONITOR] Failed to load reference data: {e}")

    def _open_with_fallback(self):
        header = ['Station', 'RelativeTime(ms)', 'Pin', 'NewState', 'Duration(ms)', 'Movement Number']

        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            self.f = open(self.path, 'w', newline='', buffering=1, encoding='utf-8')
            self.writer = csv.writer(self.f)
            self.writer.writerow(header)
            self.f.flush()
            return
        except PermissionError:
            base, ext = os.path.splitext(self.path)
            alt = f"{base}.running{ext or '.csv'}"
            print(f"[CSV] WARNING: '{self.path}' is locked (Excel?). Writing to '{alt}' instead.")
            self.path = alt
            self.f = open(self.path, 'w', newline='', buffering=1, encoding='utf-8')
            self.writer = csv.writer(self.f)
            self.writer.writerow(header)
            self.f.flush()

    def _show_popup(self, msg):
        def run_box():
            ctypes.windll.user32.MessageBoxW(0, msg, "Process Monitor Alert", 0x10 | 0x40000)
        threading.Thread(target=run_box, daemon=True).start()

    def run(self):
            self._open_with_fallback()

            while True:
                try:
                    row = event_queue.get(timeout=0.1)
                except queue.Empty:
                    if self.stop_evt.is_set():
                        break
                    continue

                try:
                    current_timer_val = float(row[1])
                    duration_val = float(row[4])
                    movement_num_from_logger = None
                    if len(row) >= 6 and row[5] not in ("", None):
                        movement_num_from_logger = int(row[5])


                    if duration_val < MIN_VALID_STATE_MS:
                        continue

                    station = str(row[0]).strip()
                    pin = str(row[2]).strip()
                    state_str = str(row[3]).strip()
                    state_norm = normalize_state_for_pin(pin, state_str)

                    if movement_num_from_logger is None:
                        # baseline / snapshot row
                        if len(row) == 5:
                            row.append("")
                    else:
                        current_mov_num = movement_num_from_logger
                        
                    if movement_num_from_logger is None:
                        self.writer.writerow(row)
                        if REALTIME_FLUSH_EVERY_ROW:
                            self.f.flush()
                            if REALTIME_FSYNC:
                                try:
                                    os.fsync(self.f.fileno())
                                except Exception:
                                    pass
                        continue
                    lookup_key = (station, pin, state_norm, current_mov_num)

                    if lookup_key in self.ref_data:
                        avg_dur, std_dur, avg_rel, std_rel = self.ref_data[lookup_key]
                        global process_delay_offset_ms

                        actual_lateness = current_timer_val - avg_rel

                        if actual_lateness > 0:
                            with process_delay_lock:
                                process_delay_offset_ms = max(process_delay_offset_ms, actual_lateness)

                        dur_limit = avg_dur + (2 * std_dur) +500
                        if duration_val > dur_limit:
                            msg = (f"Time: {now_iso()}\n"
                                   f"Error: DURATION Exceeded Limit\n\n"
                                   f"Station: {station}\n"
                                   f"Pin: {pin} (State: {state_norm})\n"
                                   f"Movement #: {current_mov_num}\n\n"
                                   f"Actual Duration: {duration_val} ms\n"
                                   f"Limit (Avg+2std+500): {dur_limit:.2f} ms")
                            print(f"[ALERT] {msg.replace(chr(10), ' ')}")
                            self._show_popup(msg)
                            self._log_duration_error(
                                station=station,
                                relative_time_ms=current_timer_val,
                                pin=pin,
                                state=state_norm,
                                movement_num=current_mov_num,
                                actual_duration=duration_val,
                                limit_ms=dur_limit,
                                ref_avg=avg_dur,
                                ref_std=std_dur
                            )

                except Exception as e:
                    print(f"[MONITOR] Error processing row: {e}")
                    if len(row) == 5:
                        row.append("ERR")

                try:
                    self.writer.writerow(row)
                    if REALTIME_FLUSH_EVERY_ROW:
                        self.f.flush()
                        if REALTIME_FSYNC:
                            try:
                                os.fsync(self.f.fileno())
                            except Exception:
                                pass
                except Exception as e:
                    print(f"[CSV] Write error: {e}")

                if self.stop_evt.is_set():
                    while True:
                        try:
                            row2 = event_queue.get_nowait()
                            if float(row2[4]) >= MIN_VALID_STATE_MS:
                                if len(row2) == 5:
                                    row2.append("")
                                self.writer.writerow(row2)
                        except queue.Empty:
                            break
                    try:
                        self.f.flush()
                        if REALTIME_FSYNC:
                            os.fsync(self.f.fileno())
                    except Exception:
                        pass
                    break

            try:
                self.f.close()
            except Exception:
                pass


# =======================
# WATCHDOG THREAD
# =======================
class WatchdogThread(threading.Thread):
    def _stop_program_on_error(self, msg, current_time_ms=None):
        global stop_time_global_ms, runner_should_run

        with stop_lock:
            if stop_time_global_ms is None and current_time_ms is not None:
                stop_time_global_ms = q10(current_time_ms)

        with queue_cv:
            runner_should_run = False
            queue_cv.notify_all()

        self._show_popup(msg + "\n\nPROGRAM STOPPED AT FIRST ERROR")
        stop_event.set()

    def __init__(self, writer_thread, stop_evt):
        super().__init__(daemon=True)
        self.writer = writer_thread
        self.stop_evt = stop_evt
        self.schedule = []
        self.alerted_events = set()
        self._load_schedule()

    def _load_schedule(self):
        if not os.path.exists(REF_FILE_PATH):
            return

        try:
            if REF_FILE_PATH.endswith('.csv'):
                df = pd.read_csv(REF_FILE_PATH)
            else:
                df = pd.read_excel(REF_FILE_PATH)

            for _, row in df.iterrows():
                try:
                    station = str(row['station']).strip()
                    pin = str(row['pin name']).strip()
                    state = normalize_state_for_pin(pin, row['newstate_norm'])
                    if state is None:
                        continue
#-----------------------------------------------------------------------------------------------------
                    mov_num = int(row['movement number'])
                    rel_avg = float(row['RelativeTime(ms)'])
                    rel_std = float(row['RelativeTime(ms)_std'])
                    deadline = rel_avg + (2 * rel_std) + 3000

                    self.schedule.append({
                        'deadline': deadline,
                        'station': station,
                        'pin': pin,
                        'state': state,
                        'mov_num': mov_num,
                        'rel_avg': rel_avg
                    })
                except Exception:
                    continue

            self.schedule.sort(key=lambda x: x['deadline'])
            print(f"[WATCHDOG] Loaded {len(self.schedule)} scheduled events.")

        except Exception as e:
            print(f"[WATCHDOG] Error loading schedule: {e}")

    def _show_popup(self, msg):
        def run_box():
            ctypes.windll.user32.MessageBoxW(0, msg, "STUCK PROCESS ALERT", 0x10 | 0x40000)
        threading.Thread(target=run_box, daemon=True).start()

    def run(self):
        while host_start_ns is None and not self.stop_evt.is_set():
            time.sleep(0.01)

        if self.stop_evt.is_set():
            return

        print("[WATCHDOG] Monitoring started (synced with global trigger)...")

        while not self.stop_evt.is_set():
            try:
                current_time_ms = (time.monotonic_ns() - host_start_ns) / 1_000_000.0

                for event in self.schedule:
                    event_key = (event['station'], event['pin'], event['state'], event['mov_num'])

                    with process_delay_lock:
                        adjusted_deadline = event['deadline'] + process_delay_offset_ms

                    if current_time_ms > adjusted_deadline:
                        if event_key in self.alerted_events:
                            continue

                        with confirmed_counts_lock:
                            current_count = confirmed_movement_counts.get(
                                (event['station'], event['pin'], event['state']), 0
                            )

                        if current_count < event['mov_num']:
                            self.alerted_events.add(event_key)

                            msg = (f"Time: {now_iso()}\n"
                               f"CRITICAL: MOVEMENT MISSING/STUCK\n\n"
                               f"Station: {event['station']}\n"
                               f"Pin: {event['pin']} (State: {event['state']})\n"
                               f"Movement #: {event['mov_num']} NOT DETECTED YET\n\n"
                               f"Current Timer: {current_time_ms:.0f} ms\n"
                               f"Adjusted Deadline: {adjusted_deadline:.0f} ms\n"
                               f"Original Deadline: {event['deadline']:.0f} ms\n"
                               f"Delay Offset: {process_delay_offset_ms:.0f} ms")

                            print(f"\n[WATCHDOG ALERT] {msg.replace(chr(10), ' ')}")
                            self._stop_program_on_error(msg, current_time_ms)
                            return

                           
                    else:
                        break

            except Exception as e:
                print(f"[WATCHDOG] Error: {e}")

            time.sleep(0.01)


# =======================
# READER THREAD
# =======================
class ESP32Logger(threading.Thread):
    def __init__(self, name, port, send_command=False, command=None, trigger_pin=None, command_delay_s=0.05):
        super().__init__(daemon=True)
        self.name = name
        self.port = port
        self.send_command = send_command
        self.command = command

        self.trigger_pin = trigger_pin
        self.command_delay_s = command_delay_s
        self.trigger_idx = None

        self.header_str = []

        # stable state 
        self.prev_states = {}
        self.prev_change_dev_ms = {}

        # pending transient state
        self.pending_states = {}
        self.pending_start_dev_ms = {}

        self.initial_snapshot_done = False
        self.snapshot_after_push9_done = False

        self.push_idx = None
        self.stop_idx = None

        self.running = True
        self._write_lock = threading.Lock()
        try:
            self.ser = serial.Serial(self.port, BAUDRATE, timeout=SER_TIMEOUT_S, write_timeout=1)
            if DEBUG:
                print(f"[{self.name}] Monitoring on {self.port}")
        except serial.SerialException as e:
            print(f"[{self.name}] ERROR: Could not open {self.port} — {e}")
            self.running = False

        if self.running:
            with logger_refs_lock:
                if self.name in logger_refs:
                    logger_refs[self.name] = self

    def send_line(self, text: str) -> bool:
            if not self.running:
                return False
            if not text.endswith("\n"):
                text = text + "\n"
            try:
                with self._write_lock:
                    self.ser.write(text.encode("utf-8", errors="ignore"))
                    self.ser.flush()
                if DEBUG:
                    print(f"[{self.name}] << {text.strip()}")
                return True
            except Exception as e:
                print(f"[{self.name}] WRITE ERROR: {e}")
                return False
    
    def _register_confirmed_movement(self, pin: str, state_bytes: bytes) -> int:
        state_str = state_bytes.decode("utf-8", errors="ignore")
        state_norm = normalize_state_for_pin(pin, state_str)

        with confirmed_counts_lock:
            confirmed_movement_counts[(self.name, pin, state_norm)] += 1
            return confirmed_movement_counts[(self.name, pin, state_norm)]

    def log_event(self, rel_time_ms: int, pin: str, state_bytes: bytes, duration_ms: int, movement_num=None):
                row = [
                    self.name,
                    rel_time_ms,
                    pin,
                    state_bytes.decode("utf-8", errors="ignore"),
                    duration_ms
                ]
                if movement_num is not None:
                    row.append(movement_num)
                event_queue.put(row)

    def close(self):
        self.running = False

    def _commit_confirmed_transition(self, pin, new_state_b, change_dev_ms, station_zero_ms):
        stable_t = self.prev_change_dev_ms.get(pin)

        if stable_t is None or stable_t < station_zero_ms:
            effective_start = station_zero_ms
        else:
            effective_start = stable_t

        clipped_duration = change_dev_ms - effective_start
        if clipped_duration < 0:
            clipped_duration = 0

        if QUANTIZE_10MS:
            duration_ms_out = q10(clipped_duration)
        else:
            duration_ms_out = int(clipped_duration)

        rel_event_ms = change_dev_ms - station_zero_ms
        if rel_event_ms < 0:
            rel_event_ms = 0

        rel_event_ms_q = q10(rel_event_ms)

        if duration_ms_out >= MIN_VALID_STATE_MS:
            movement_num = self._register_confirmed_movement(pin, new_state_b)
            self.log_event(rel_event_ms_q, pin, new_state_b, duration_ms_out, movement_num)

        self.prev_states[pin] = new_state_b
        self.prev_change_dev_ms[pin] = change_dev_ms

    def run(self):
        global global_dev_zero_ms, host_start_ns, stop_time_global_ms
        global pending_stop_time_ms, pending_snapshot_time_ms

        if not self.running:
            return

        if DEBUG:
            print(f"[{self.name}] Waiting for header on {self.port}...")

        header_seen = False
        header_start_time = time.perf_counter()

        # =========================
        # 1) Wait for header
        # =========================
        while self.running and not stop_event.is_set():
            try:
                line = self.ser.readline()
            except serial.SerialException:
                print(f"[{self.name}] Serial exception while waiting for header.")
                return

            if not line:
                if (
                    self.trigger_pin is not None
                    and (time.perf_counter() - header_start_time) > TRIGGER_WARN_AFTER_S
                    and not header_seen
                ):
                    print(f"[{self.name}] Waiting for header... (no header after {TRIGGER_WARN_AFTER_S:.1f}s)")
                    header_start_time = time.perf_counter()
                continue

            parts = line.rstrip(b"\r\n").split(b",")
            if len(parts) < 2:
                continue

            if parts[0].strip().lower() == b"timestamp(ms)":
                header_seen = True
                header_bytes = [x.strip() for x in parts[1:]]
                self.header_str = [h.decode("utf-8", errors="ignore") for h in header_bytes]

                if self.trigger_pin is not None:
                    try:
                        self.trigger_idx = self.header_str.index(self.trigger_pin)
                    except ValueError:
                        self.trigger_idx = None
                        print(f"[{self.name}] WARNING: configured trigger pin '{self.trigger_pin}' not present in this header.")

                try:
                    self.push_idx = self.header_str.index(VALVE_PUSH_COUNT_COL)
                except ValueError:
                    self.push_idx = None

                try:
                    self.stop_idx = self.header_str.index(STOP_FLAG_COL)
                except ValueError:
                    self.stop_idx = None

                for pin in self.header_str:
                    self.prev_states[pin] = None
                    self.prev_change_dev_ms[pin] = None
                    self.pending_states[pin] = None
                    self.pending_start_dev_ms[pin] = None

                break

        # =========================
        # 2) Main read loop
        # =========================
        while self.running and not stop_event.is_set():
            try:
                raw = self.ser.readline()
                if not raw:
                    continue
                parts = raw.rstrip(b"\r\n").split(b",")
            except serial.SerialException:
                print(f"[{self.name}] Serial exception while reading.")
                break

            if len(parts) < 2:
                continue

            try:
                dev_ts_ms = int(parts[0].strip())
            except Exception:
                continue

            states_bytes = [x.strip() for x in parts[1:]]
            n = len(self.header_str)
            if len(states_bytes) < n:
                states_bytes.extend([self.prev_states.get(self.header_str[i], b"")] * (n - len(states_bytes)))
            elif len(states_bytes) > n:
                states_bytes = states_bytes[:n]

            # =========================
            # A) latch global zero
            # =========================
            if global_dev_zero_ms is None and self.trigger_idx is not None:
                try:
                    if is_high_bytes(states_bytes[self.trigger_idx]):
                        global_dev_zero_ms = dev_ts_ms
                        host_start_ns = time.monotonic_ns()

                        with station_offsets_lock:
                            station_offsets_ms[self.name] = 0.0

                        for pin, valb in zip(self.header_str, states_bytes):
                            self.log_event(0, pin, valb, 0)
                        self.initial_snapshot_done = True
                except Exception:
                    pass

            # =========================
            # B) before global zero
            # =========================
            if global_dev_zero_ms is None:
                for pin, valb in zip(self.header_str, states_bytes):
                    if self.prev_states[pin] is None:
                        self.prev_states[pin] = valb
                        self.prev_change_dev_ms[pin] = dev_ts_ms
                        self.pending_states[pin] = None
                        self.pending_start_dev_ms[pin] = None
                continue

            # =========================
            # C) estimate station offset once
            # =========================
            with station_offsets_lock:
                if self.name not in station_offsets_ms:
                    elapsed_host_ms = (time.monotonic_ns() - host_start_ns) / 1_000_000.0 if host_start_ns else 0.0
                    estimated_offset = dev_ts_ms - elapsed_host_ms - global_dev_zero_ms
                    station_offsets_ms[self.name] = estimated_offset
                    if DEBUG:
                        print(f"[{self.name}] Station offset estimated: {estimated_offset:.2f} ms")

            station_zero_ms = global_dev_zero_ms + station_offsets_ms[self.name]
            rel_time_ms = dev_ts_ms - station_zero_ms
            rel_time_ms_q = q10(rel_time_ms)

            # =========================
            # D) initial snapshot once
            # =========================
            if not self.initial_snapshot_done:
                for pin, valb in zip(self.header_str, states_bytes):
                    self.log_event(0, pin, valb, 0)
                self.initial_snapshot_done = True

            # =========================
            # E) scheduled snapshot
            # =========================
            with stop_lock:
                scheduled_snapshot = pending_snapshot_time_ms

            if (
                scheduled_snapshot is not None
                and not self.snapshot_after_push9_done
                and rel_time_ms_q >= scheduled_snapshot
            ):
                snapshot_dev_ms = station_zero_ms + scheduled_snapshot

                for pin, raw_valb in zip(self.header_str, states_bytes):
                    stable_b = self.prev_states.get(pin)
                    stable_t = self.prev_change_dev_ms.get(pin)

                    pending_b = self.pending_states.get(pin)
                    pending_t = self.pending_start_dev_ms.get(pin)

                    snap_b = stable_b if stable_b is not None else raw_valb
                    snap_t = stable_t

                    if pending_b is not None and pending_t is not None:
                        if (snapshot_dev_ms - pending_t) >= MIN_VALID_STATE_MS:
                            snap_b = pending_b
                            snap_t = pending_t

                    if snap_t is None or snap_t < station_zero_ms:
                        effective_start = station_zero_ms
                    else:
                        effective_start = snap_t

                    effective_start_rel = effective_start - station_zero_ms
                    duration_at_snapshot = scheduled_snapshot - effective_start_rel
                    if duration_at_snapshot < 0:
                        duration_at_snapshot = 0

                    if QUANTIZE_10MS:
                        duration_out = q10(duration_at_snapshot)
                    else:
                        duration_out = int(round(duration_at_snapshot))

                    self.log_event(scheduled_snapshot, pin, snap_b, duration_out)

                self.snapshot_after_push9_done = True

            # =========================
            # F) ColorSorter stop logic
            # =========================
            if self.name == "ESP32_ColorSorter":
                push_count = None
                stop_flag = False

                if self.push_idx is not None:
                    try:
                        push_count = int(states_bytes[self.push_idx])
                    except Exception:
                        push_count = None

                if self.stop_idx is not None:
                    stop_flag = (states_bytes[self.stop_idx] == b"1")

                if stop_flag:
                    with stop_lock:
                        stop_time_global_ms = rel_time_ms_q
                    stop_event.set()
                    break

                if push_count is not None and push_count >= 9:
                    with stop_lock:
                        if pending_snapshot_time_ms is None:
                            pending_snapshot_time_ms = rel_time_ms_q + SNAP_AFTER_9TH_PUSH_DELAY_MS
                        if pending_stop_time_ms is None:
                            pending_stop_time_ms = rel_time_ms_q + STOP_DELAY_AFTER_9TH_PUSH_MS

                with stop_lock:
                    scheduled_stop = pending_stop_time_ms

                if scheduled_stop is not None and rel_time_ms_q >= scheduled_stop:
                    with stop_lock:
                        if stop_time_global_ms is None:
                            stop_time_global_ms = scheduled_stop
                    stop_event.set()
                    break

            # =========================
            # G) Debounced state tracking
            # =========================
            for pin, current_b in zip(self.header_str, states_bytes):
                stable_b = self.prev_states.get(pin)
                stable_t = self.prev_change_dev_ms.get(pin)
                pending_b = self.pending_states.get(pin)
                pending_t = self.pending_start_dev_ms.get(pin)

                # COLOR_CODE 
                if pin == COLOR_CODE_PIN:
                    if stable_b is None:
                        self.prev_states[pin] = current_b
                        self.prev_change_dev_ms[pin] = dev_ts_ms
                        self.pending_states[pin] = None
                        self.pending_start_dev_ms[pin] = None
                        continue

                    if current_b != stable_b:
                        if stable_t is None or stable_t < station_zero_ms:
                            effective_start = station_zero_ms
                        else:
                            effective_start = stable_t

                        clipped_duration = dev_ts_ms - effective_start
                        if clipped_duration < 0:
                            clipped_duration = 0

                        if QUANTIZE_10MS:
                            duration_ms_out = q10(clipped_duration)
                        else:
                            duration_ms_out = int(clipped_duration)

                        if duration_ms_out >= MIN_VALID_STATE_MS:
                            movement_num = self._register_confirmed_movement(pin, current_b)
                            self.log_event(rel_time_ms_q, pin, current_b, duration_ms_out, movement_num)

                        self.prev_states[pin] = current_b
                        self.prev_change_dev_ms[pin] = dev_ts_ms
                        self.pending_states[pin] = None
                        self.pending_start_dev_ms[pin] = None

                    continue

                if stable_b is None:
                    self.prev_states[pin] = current_b
                    self.prev_change_dev_ms[pin] = dev_ts_ms
                    self.pending_states[pin] = None
                    self.pending_start_dev_ms[pin] = None
                    continue

                
                if pending_b is None:
                    if current_b != stable_b:
                        self.pending_states[pin] = current_b
                        self.pending_start_dev_ms[pin] = dev_ts_ms
                    continue

                pending_age = dev_ts_ms - pending_t

                
                if current_b == pending_b:
                    if pending_age >= MIN_VALID_STATE_MS:
                        self._commit_confirmed_transition(pin, pending_b, pending_t, station_zero_ms)
                        self.pending_states[pin] = None
                        self.pending_start_dev_ms[pin] = None
                    continue

                
                if current_b == stable_b:
                    if pending_age < MIN_VALID_STATE_MS:
                        
                        self.pending_states[pin] = None
                        self.pending_start_dev_ms[pin] = None
                    else:
                        
                        self._commit_confirmed_transition(pin, pending_b, pending_t, station_zero_ms)

                        
                        self.pending_states[pin] = current_b
                        self.pending_start_dev_ms[pin] = dev_ts_ms
                    continue

                
                if pending_age < MIN_VALID_STATE_MS:
                    self.pending_states[pin] = current_b
                    self.pending_start_dev_ms[pin] = dev_ts_ms
                else:
                    self._commit_confirmed_transition(pin, pending_b, pending_t, station_zero_ms)
                    self.pending_states[pin] = current_b
                    self.pending_start_dev_ms[pin] = dev_ts_ms

        try:
            if self.ser.is_open:
                self.ser.close()
        except Exception:
            pass


# =======================
# BACKGROUND ORDER WORKER
# =======================
def load_preset_setup(clear_existing=True, auto_start=True):
    global runner_should_run

    with position_colors_lock:
        position_colors.clear()
        position_colors.update(PRESET_SELECTIONS)

    with queue_cv:
        if clear_existing:
            order_queue.clear()

        for spec in PRESET_QUEUE:
            pos = spec["pos"]
            machining = spec["machining"]
            post_ops = list(spec["post_ops"])
            color = PRESET_SELECTIONS.get(pos)

            if not color:
                continue

            include_painting = any(op.lower() == "painting" for op in post_ops)
            include_cleaning = any(op.lower() == "cleaning" for op in post_ops)

            if include_painting and color.lower() == "white":
                continue

            if include_cleaning and not include_painting and color.lower() != "white":
                continue

            already = any(
                it['pos'] == pos and it['status'] in ('Pending', 'Processing', 'Done')
                for it in order_queue
            )
            if already:
                continue

            item = {
                "id": str(uuid.uuid4()),
                "pos": pos,
                "color": color,
                "machining": machining,
                "post_ops": post_ops,
                "status": "Pending",
                "message": "Auto-loaded preset",
                "ts": now_iso()
            }
            order_queue.append(item)

        if auto_start and any(item['status'] == 'Pending' for item in order_queue):
            runner_should_run = True

        queue_cv.notify_all()
        
class OrderWorker(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)

    def run(self):
        global runner_should_run
        while not stop_event.is_set():
            with queue_cv:
                while (not runner_should_run or not any(item['status'] == 'Pending' for item in order_queue)) and not stop_event.is_set():
                    queue_cv.wait(timeout=0.5)
                if stop_event.is_set():
                    break

                next_idx = None
                for i, item in enumerate(order_queue):
                    if item['status'] == 'Pending':
                        next_idx = i
                        break
                if next_idx is None:
                    continue

                job = order_queue[next_idx]
                job['status'] = 'Processing'
                job['message'] = 'Sending to HBW...'

            self.process_job(job)

    def process_job(self, job):
        pos = job['pos']
        machining = job['machining']
        post_ops = job['post_ops']
        color = job['color']

        include_painting = any(x.lower() == 'painting' for x in post_ops)
        include_cleaning = any(x.lower() == 'cleaning' for x in post_ops)
        oven_msg = machining + ((", " + ", ".join(sorted(post_ops))) if post_ops else "")

        with order_state_lock:
            if pos in emptied_positions:
                return self._fail(job, "Position already empty at runtime.")
            if not color:
                return self._fail(job, "No color on position.")
            if include_painting and color.lower() == 'white':
                return self._fail(job, "Painting selected but position is WHITE.")
            if include_cleaning and not include_painting and color.lower() != 'white':
                return self._fail(job, "Cleaning-only selected but position is not WHITE.")

        with logger_refs_lock:
            hbw = logger_refs.get('ESP32_HBW')
            oven = logger_refs.get('ESP32_Oven')

        if (hbw is None) or (not getattr(hbw, "running", False)):
            return self._fail(job, "HBW serial not open (check COM port / cable / in-use).")

        try:
            idx = int(pos.replace("Pos", ""))
        except Exception:
            return self._fail(job, "Invalid position label.")

        if not (1 <= idx <= 9):
            return self._fail(job, "Position index out of range.")

        if DEBUG:
            print(f"[QUEUE] Sending to HBW: RETRIEVE POS{idx}")
        ok_hbw = hbw.send_line(f"RETRIEVE POS{idx}")
        if DEBUG:
            print(f"[QUEUE] HBW send result: {ok_hbw}")

        if not ok_hbw:
            return self._fail(job, "HBW write failed.")

        oven_sent = False
        if oven is not None and getattr(oven, "running", False):
            oven_sent = oven.send_line(oven_msg)

        with order_state_lock:
            emptied_positions.add(pos)

        with queue_lock:
            job['status'] = 'Done'
            job['message'] = f"HBW ok; Oven {'sent' if oven_sent else 'not sent'}."

    def _fail(self, job, msg):
        with queue_lock:
            job['status'] = 'Failed'
            job['message'] = msg


order_worker = OrderWorker()
order_worker.start()

# =======================
# DASHBOARD SERVER (HTTP + UI)
# =======================
HTML_PAGE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Factory Grid & Order Queue</title>
<style>
  :root { --cell-size: 140px; --gap: 14px; --bg:#0f172a; --card:#111827; --text:#ffffff; --muted:#94a3b8; --ring:#22d3ee; }
  * { box-sizing: border-box; font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Arial; }
  body { margin:0; padding:24px; background:linear-gradient(180deg, var(--bg), #020617); color:var(--text); display:grid; place-items:center; min-height:100vh;}
  .wrap { width:min(95vw, 1100px); }
  h1 { margin: 0 0 10px 0; font-weight:700; letter-spacing:.3px; font-size: clamp(18px, 2.5vw, 24px); color:var(--text); }
  h2 { margin: 10px 0; font-size: 16px; color: var(--text); }
  .meta { display:flex; gap:10px; align-items:center; margin-bottom:14px; flex-wrap:wrap; }
  .badge { font-size:12px; padding:6px 10px; border:1px solid rgba(255,255,255,.12); border-radius: 999px; background:#0b1220; color:var(--text); }

  .grid { display:grid; grid-template-columns: repeat(3, var(--cell-size)); grid-template-rows:repeat(3, var(--cell-size)); gap:var(--gap); justify-content:center; }
  .cell {
    position:relative; background: radial-gradient(120% 120% at 100% 0%, rgba(34,211,238,0.08) 0%, rgba(34,211,238,0) 60%), var(--card);
    border:1px solid rgba(255,255,255,0.1); border-radius:16px; display:grid; place-items:center;
    user-select:none; cursor:pointer; transition: transform .12s ease-out, border-color .12s ease-out, box-shadow .12s ease-out;
    box-shadow: 0 10px 30px rgba(0,0,0,.35), inset 0 0 0 1px rgba(255,255,255,.02);
  }
  .cell:hover { transform: translateY(-2px); border-color: rgba(34,211,238,0.5); box-shadow:0 12px 38px rgba(0,0,0,.45); }
  .cell.disabled { opacity:.35; cursor:not-allowed; filter: grayscale(0.3); }
  .cell.not-eligible { opacity:.45; cursor:not-allowed; outline: 2px dashed rgba(239,68,68,.35); }
  .cell.selectable { outline: 2px dashed rgba(34,211,238,.35); }
  .cell.selected { outline: 3px solid var(--ring); }
  .cell.queued { opacity:.6; cursor:not-allowed; outline: 2px dashed rgba(250,204,21,.45); }

  .label { font-weight:700; font-size:clamp(14px,2.2vw,20px); letter-spacing:.4px; color:var(--text); pointer-events:none; }
  .dot { position:absolute; width:56%; height:56%; border-radius:999px; border:2px solid rgba(255,255,255,.12); inset:0; margin:auto; display:none; }
  .dot.visible { display:block; }
  .c-white{ background:#ffffff; } .c-red{ background:#ef4444; } .c-blue{ background:#3b82f6; }
  .pos1{grid-row:1;grid-column:1;} .pos2{grid-row:2;grid-column:1;} .pos3{grid-row:3;grid-column:1;}
  .pos4{grid-row:1;grid-column:2;} .pos5{grid-row:2;grid-column:2;} .pos6{grid-row:3;grid-column:2;}
  .pos7{grid-row:1;grid-column:3;} .pos8{grid-row:2;grid-column:3;} .pos9{grid-row:3;grid-column:3;}

  footer { margin-top:16px; opacity:.7; font-size:12px; text-align:center; color:var(--muted); }

  .btn { appearance:none; border:1px solid rgba(255,255,255,.14); background:#0f172a; color:var(--text);
         padding:10px 14px; border-radius:12px; font-weight:600; cursor:pointer; transition: transform .08s ease, border-color .12s ease; }
  .btn:hover { transform: translateY(-1px); border-color: var(--ring); }
  .btn:disabled { opacity:.5; cursor:not-allowed; transform:none; }

  .picker-backdrop { position:fixed; inset:0; background:rgba(2,6,23,.55); display:none; align-items:center; justify-content:center; z-index:50; }
  .picker { background:#0b1220; border:1px solid rgba(255,255,255,.1); border-radius:14px; padding:14px; min-width:280px; box-shadow:0 10px 40px rgba(0,0,0,.5); color:var(--text); }
  .choices { display:flex; gap:8px; }
  .choice-btn { flex:1; padding:10px; border-radius:10px; border:1px solid rgba(255,255,255,.12); background:#0f172a; color:var(--text); font-weight:600; cursor:pointer; }
  .choice-btn:hover { outline:2px solid var(--ring); }
  .choice-btn[disabled]{ opacity:.35; cursor:not-allowed; outline:none; }
  .row { display:flex; justify-content:space-between; gap:10px; margin-top:10px; font-size:12px; color:var(--muted); }
  .close { margin-top:10px; width:100%; padding:8px; font-size:12px; background:#0f172a; color:var(--text); border:1px solid rgba(255,255,255,.12); border-radius:10px; cursor:pointer; }

  .page { display:none; } .page.active { display:block; }

  .layout-order { display:grid; grid-template-columns: 320px 1fr; gap:16px; align-items:start; }
  .mini { --cell-size:64px; }
  .mini .grid { grid-template-columns: repeat(3, var(--cell-size)); grid-template-rows: repeat(3, var(--cell-size)); }
  .mini .label { font-size:12px; }
  .mini .dot { width:48%; height:48%; }

  .cards { display:grid; grid-template-columns: repeat(2, minmax(220px, 1fr)); gap:12px; margin-top:8px; }
  .card {
    background: radial-gradient(120% 120% at 100% 0%, rgba(34,211,238,0.08) 0%, rgba(34,211,238,0) 60%), var(--card);
    border:1px solid rgba(255,255,255,0.1); border-radius:16px; padding:14px; cursor:pointer; user-select:none; color:var(--text);
  }
  .card:hover { outline:2px solid rgba(34,211,238,0.35); }
  .card.selected { outline:2px solid var(--ring); }
  .section { margin:14px 0; }
  .summary { margin-top:8px; font-size:13px; color:var(--muted); }
  .divider { height:1px; background: rgba(255,255,255,.08); margin:12px 0; }

  table { width:100%; border-collapse: collapse; margin-top:8px; }
  th, td { border-bottom: 1px solid rgba(255,255,255,.08); padding:8px; font-size:13px; text-align:left; }
  th { color:#e2e8f0; }
  .status-Pending { color:#fbbf24; }
  .status-Processing { color:#22d3ee; }
  .status-Done { color:#86efac; }
  .status-Failed { color:#f87171; }
</style>
</head>
<body>
  <div class="wrap">
    <div id="page-grid" class="page active" aria-label="Color assignment page">
      <h1>Factory Positions</h1>
      <div class="meta">
        <span class="badge" id="rem-white">White remaining: 3</span>
        <span class="badge" id="rem-red">Red remaining: 3</span>
        <span class="badge" id="rem-blue">Blue remaining: 3</span>
      </div>
      <div class="grid" id="main-grid"></div>
      <div class="section" style="display:flex; justify-content:flex-end; margin-top:14px;">
        <button id="btn-next" class="btn">Next →</button>
      </div>
      <footer>Click a square to choose a color. Each color can be used at most 3 times.</footer>
    </div>

    <div id="page-order" class="page" aria-label="Order page">
      <div class="layout-order">
        <div>
          <h2>Select one piece</h2>
          <div class="mini"><div class="grid" id="mini-grid"></div></div>
          <div class="summary" id="selected-pos-label">Selected: none</div>
          <div class="summary" id="eligibility-note"></div>
          <div class="section" style="display:flex; gap:8px; flex-wrap:wrap;">
            <button id="btn-add-queue" class="btn">Add to Queue</button>
            <button id="btn-start" class="btn">Start Auto-Run</button>
            <button id="btn-stop" class="btn">Stop</button>
            <button id="btn-clear" class="btn">Clear Pending</button>
          </div>
          <div class="section">
            <h2>Queue</h2>
            <table id="qtable">
              <thead><tr><th>#</th><th>Pos</th><th>Color</th><th>Machining</th><th>Post-ops</th><th>Status</th><th>Note</th><th>Time</th></tr></thead>
              <tbody id="qbody"></tbody>
            </table>
          </div>
        </div>

        <div>
          <h1>Order Setup</h1>
          <div class="summary" id="summary-colors"></div>
          <div class="divider"></div>

          <div class="section">
            <h2>Choose machining</h2>
            <div class="cards" id="machining-cards">
              <div class="card" data-machining="NO machining">a. NO machining</div>
              <div class="card" data-machining="Basic shape">b. Basic shape</div>
              <div class="card" data-machining="Advance shape">c. Advance shape</div>
              <div class="card" data-machining="Extra shape">d. Extra shape</div>
            </div>
          </div>

          <div class="section" id="post-ops-section" style="display:none;">
            <h2>Post operations</h2>
            <div class="cards" id="postops-cards">
              <div class="card postop" data-toggle="Cleaning">Cleaning</div>
              <div class="card postop" data-toggle="Painting">Painting</div>
            </div>
          </div>

          <footer style="margin-top:16px;">
            Rules: If Painting selected → white is not allowed. If only Cleaning selected → only white is allowed.  
            Auto-run sends exactly one HBW command and, on success, one Oven command per order.
          </footer>
        </div>
      </div>
    </div>
  </div>

  <div class="picker-backdrop" id="picker-backdrop" role="dialog" aria-modal="true">
    <div class="picker" role="document">
      <h2 id="picker-title">Choose color for <span id="picker-pos"></span></h2>
      <div class="choices">
        <button class="choice-btn" id="pick-white" data-color="white">White</button>
        <button class="choice-btn" id="pick-red" data-color="red">Red</button>
        <button class="choice-btn" id="pick-blue" data-color="blue">Blue</button>
      </div>
      <div class="row">
        <span id="count-white">White remaining: 3</span>
        <span id="count-red">Red remaining: 3</span>
        <span id="count-blue">Blue remaining: 3</span>
      </div>
      <button class="close" id="close-picker">Close</button>
    </div>
  </div>

<script>
(function() {
  const API = {
    add:   () => location.origin + '/api/queue/add',
    start: () => location.origin + '/api/queue/start',
    stop:  () => location.origin + '/api/queue/stop',
    clear: () => location.origin + '/api/queue/clear',
    stat:  () => location.origin + '/api/queue/status',
    diag:  () => location.origin + '/api/diag',
    hbwSend: () => location.origin + '/api/hbw/send',
  };

  const MAX_PER_COLOR = 3;
  const colors = ['white','red','blue'];
  const colorClass = { white: 'c-white', red: 'c-red', blue: 'c-blue' };
  const counts = { white: 0, red: 0, blue: 0 };
  const selections = {}; // pos -> color
  const emptied = new Set();
  const queued = new Set();
  const posList = ['Pos1','Pos2','Pos3','Pos4','Pos5','Pos6','Pos7','Pos8','Pos9'];

  let chosenPos = null;
  let selectedMachining = null;
  const selectedPostOps = new Set();

  function buildGrid(containerId, selectable=false) {
    const c = document.getElementById(containerId);
    c.innerHTML = '';
    posList.forEach((pos, idx) => {
      const cell = document.createElement('div');
      cell.className = `cell pos${idx+1}` + (selectable ? ' selectable' : '');
      cell.setAttribute('data-pos', pos);
      const label = document.createElement('div'); label.className='label'; label.textContent=pos;
      const dot = document.createElement('div'); dot.className='dot'; dot.id=(selectable?'mini-dot-':'dot-')+pos;
      cell.appendChild(label); cell.appendChild(dot);

      if (selectable) {
        cell.addEventListener('click', () => {
          if (emptied.has(pos) || cell.classList.contains('not-eligible') || cell.classList.contains('queued')) return;
          document.querySelectorAll('#mini-grid .cell').forEach(el => el.classList.remove('selected'));
          if (chosenPos === pos) { chosenPos = null; }
          else { chosenPos = pos; cell.classList.add('selected'); }
          updateSelectedLabel();
        });
      } else {
        cell.addEventListener('click', () => {
          if (emptied.has(pos)) return;
          openPickerFor(pos);
        });
      }
      c.appendChild(cell);
    });
  }

  const pageGrid = document.getElementById('page-grid');
  const pageOrder = document.getElementById('page-order');
  const remWhite = document.getElementById('rem-white');
  const remRed   = document.getElementById('rem-red');
  const remBlue  = document.getElementById('rem-blue');
  const summaryColors = document.getElementById('summary-colors');
  const selectedPosLabel = document.getElementById('selected-pos-label');
  const eligibilityNote = document.getElementById('eligibility-note');

  const backdrop = document.getElementById('picker-backdrop');
  const pickerPos = document.getElementById('picker-pos');
  const btnWhite = document.getElementById('pick-white');
  const btnRed = document.getElementById('pick-red');
  const btnBlue = document.getElementById('pick-blue');
  const btnClose = document.getElementById('close-picker');

  const cWhite = document.getElementById('count-white');
  const cRed   = document.getElementById('count-red');
  const cBlue  = document.getElementById('count-blue');

  const btnNext = document.getElementById('btn-next');
  const btnAddQ = document.getElementById('btn-add-queue');
  const btnStart = document.getElementById('btn-start');
  const btnStop = document.getElementById('btn-stop');
  const btnClear = document.getElementById('btn-clear');
  const machiningCards = document.getElementById('machining-cards');
  const postOpsSection = document.getElementById('post-ops-section');
  const postOpsCards = document.getElementById('postops-cards');

  const qbody = document.getElementById('qbody');

  buildGrid('main-grid', false);
  buildGrid('mini-grid', true);

  function updateCountersUI() {
    remWhite.textContent = `White remaining: ${MAX_PER_COLOR - counts.white}`;
    remRed.textContent   = `Red remaining: ${MAX_PER_COLOR - counts.red}`;
    remBlue.textContent  = `Blue remaining: ${MAX_PER_COLOR - counts.blue}`;
    cWhite.textContent = remWhite.textContent; cRed.textContent = remRed.textContent; cBlue.textContent = remBlue.textContent;
  }

  function syncDots() {
    posList.forEach(pos => {
      const dot = document.getElementById('dot-' + pos);
      const mdot = document.getElementById('mini-dot-' + pos);
      const color = selections[pos] || null;
      [dot, mdot].forEach(d => {
        if (!d) return;
        d.classList.remove('c-white','c-red','c-blue','visible');
        if (color) { d.classList.add(colorClass[color], 'visible'); }
      });
      document.querySelectorAll(`.cell[data-pos="${pos}"]`).forEach(cell=>{
        cell.classList.remove('queued');
        if (emptied.has(pos)) cell.classList.add('disabled'); else cell.classList.remove('disabled');
        if (queued.has(pos)) cell.classList.add('queued');
      });
    });
  }

  function updateSelectedLabel() {
    selectedPosLabel.textContent = 'Selected: ' + (chosenPos || 'none');
  }

  function updateMiniGridEligibility() {
    const includePainting = Array.from(selectedPostOps).some(x => x.toLowerCase()==='painting');
    const includeCleaning = Array.from(selectedPostOps).some(x => x.toLowerCase()==='cleaning');

    if (includePainting) {
      eligibilityNote.textContent = "Painting selected → White positions are not eligible.";
    } else if (includeCleaning) {
      eligibilityNote.textContent = "Cleaning-only selected → Only White positions are eligible.";
    } else {
      eligibilityNote.textContent = "No post-ops selected → Any color is eligible.";
    }

    document.querySelectorAll('#mini-grid .cell').forEach(cell => {
        const pos = cell.getAttribute('data-pos');
        const color = selections[pos] || null;
        let eligible = true;

        if (emptied.has(pos)) eligible = false;
        if (queued.has(pos))  eligible = false;

        if (includePainting) {
            if (color === 'white') eligible = false;
        }

        if (includeCleaning && !includePainting) {
            if (color !== 'white') eligible = false;
        }

        if (!color) eligible = false;

        cell.classList.remove('not-eligible', 'selected');
        if (!eligible) {
            cell.classList.add('not-eligible');
            if (chosenPos === pos) chosenPos = null;
        }
    });

    updateSelectedLabel();
  }

  function openPickerFor(pos) {
    pickerPos.textContent = pos;
    activePos = pos;
    const current = selections[pos] || null;
    [btnWhite, btnRed, btnBlue].forEach(btn => {
      const color = btn.dataset.color;
      const exhausted = counts[color] >= MAX_PER_COLOR;
      btn.disabled = exhausted && current !== color;
    });
    updateCountersUI();
    backdrop.style.display = 'flex';
  }
  function closePicker(){ backdrop.style.display='none'; activePos=null; }
  let activePos = null;

  function setColor(pos, color) {
    if (emptied.has(pos)) { closePicker(); return; }
    const prev = selections[pos] || null;
    if (prev === color) { closePicker(); return; }
    if (prev) counts[prev] = Math.max(0, counts[prev]-1);
    if (counts[color] >= MAX_PER_COLOR) {
      alert(`Limit reached: ${color} can only be used ${MAX_PER_COLOR} times.`);
      updateCountersUI(); syncDots(); return;
    }
    counts[color] += 1;
    selections[pos] = color;
    updateCountersUI();
    syncDots();
    updateMiniGridEligibility();
    closePicker();
  }

  function goToOrderPage() {
    const grouped = { white:[], red:[], blue:[] };
    Object.entries(selections).forEach(([pos,col])=> grouped[col]?.push(pos));
    const parts = [];
    colors.forEach(c => { if (grouped[c] && grouped[c].length) parts.push(`${c.toUpperCase()}: ${grouped[c].sort().join(', ')}`); });
    summaryColors.textContent = parts.length ? ("Colors → " + parts.join(" | ")) : "No colors selected.";
    pageGrid.classList.remove('active'); pageOrder.classList.add('active');
    syncDots(); updateSelectedLabel(); updateMiniGridEligibility();
  }

  function selectMachining(card) {
    machiningCards.querySelectorAll('.card').forEach(c => c.classList.remove('selected'));
    card.classList.add('selected');
    selectedMachining = card.getAttribute('data-machining');
    postOpsSection.style.display = 'block';
    updateMiniGridEligibility();
  }
  function togglePostOp(card) {
    const op = card.getAttribute('data-toggle');
    if (card.classList.contains('selected')) { card.classList.remove('selected'); selectedPostOps.delete(op); }
    else { card.classList.add('selected'); selectedPostOps.add(op); }
    updateMiniGridEligibility();
  }

  async function refreshQueue() {
  try {
    const res = await fetch(API.stat());
    if (!res.ok) return;
    const data = await res.json();

    if (data.selections && typeof data.selections === 'object') {
      Object.keys(selections).forEach(k => delete selections[k]);
      Object.assign(selections, data.selections);
    }

    counts.white = 0;
    counts.red = 0;
    counts.blue = 0;

    Object.values(selections).forEach(color => {
      if (color === 'white' || color === 'red' || color === 'blue') {
        counts[color]++;
      }
    });

    updateCountersUI();

    queued.clear();
    if (Array.isArray(data.queued)) {
      data.queued.forEach(p => queued.add(p));
    }

    if (Array.isArray(data.emptied)) {
      emptied.clear();
      data.emptied.forEach(p => emptied.add(p));
    }

    qbody.innerHTML = '';
    (data.queue || []).forEach((item, i) => {
      const tr = document.createElement('tr');
      const td = (t) => {
        const e = document.createElement('td');
        e.textContent = t;
        return e;
      };

      tr.appendChild(td(String(i + 1)));
      tr.appendChild(td(item.pos));
      tr.appendChild(td(item.color || ''));
      tr.appendChild(td(item.machining));
      tr.appendChild(td((item.post_ops || []).join(' + ')));

      const st = document.createElement('td');
      st.textContent = item.status;
      st.className = 'status-' + item.status;
      tr.appendChild(st);

      tr.appendChild(td(item.message || ''));
      tr.appendChild(td(item.ts || ''));
      qbody.appendChild(tr);
    });

    syncDots();
    updateMiniGridEligibility();

    const hasSelections = Object.keys(selections).length > 0;
    const hasQueue = Array.isArray(data.queue) && data.queue.length > 0;

    if (hasSelections && hasQueue && !pageOrder.classList.contains('active')) {
      goToOrderPage();
    }

  } catch {}
}

  async function addToQueue() {
    if (!selectedMachining) { alert("Choose a machining option first."); return; }
    if (!chosenPos) { alert("Select one eligible position on the mini grid."); return; }
    if (queued.has(chosenPos)) { alert(`${chosenPos} is already in the queue.`); return; }

    const ops = Array.from(selectedPostOps);
    const payload = {
      machining: selectedMachining,
      post_ops: ops,
      chosen_pos: chosenPos,
      selections: selections
    };
    const res = await fetch(API.add(), { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload) });
    const data = await res.json();
    if (!res.ok || data.error) { alert('Add failed: ' + (data.error || res.status)); return; }
    chosenPos = null; updateSelectedLabel();
    await refreshQueue();
  }

  async function startRunner() {
    await fetch(API.start(), { method:'POST' });
    await refreshQueue();
  }
  async function stopRunner() {
    await fetch(API.stop(), { method:'POST' });
    await refreshQueue();
  }
  async function clearPending() {
    await fetch(API.clear(), { method:'POST' });
    await refreshQueue();
  }

  document.getElementById('btn-next').addEventListener('click', goToOrderPage);
  btnWhite.addEventListener('click', ()=> activePos && setColor(activePos,'white'));
  btnRed  .addEventListener('click', ()=> activePos && setColor(activePos,'red'));
  btnBlue .addEventListener('click', ()=> activePos && setColor(activePos,'blue'));
  btnClose.addEventListener('click', ()=> closePicker());
  document.getElementById('picker-backdrop').addEventListener('click', (e)=>{ if (e.target.id==='picker-backdrop') closePicker(); });

  machiningCards.querySelectorAll('.card').forEach(card => card.addEventListener('click', ()=> selectMachining(card)));
  postOpsCards.querySelectorAll('.card.postop').forEach(card => card.addEventListener('click', ()=> togglePostOp(card)));

  document.getElementById('btn-add-queue').addEventListener('click', addToQueue);
  document.getElementById('btn-start').addEventListener('click', startRunner);
  document.getElementById('btn-stop').addEventListener('click', stopRunner);
  document.getElementById('btn-clear').addEventListener('click', clearPending);

  updateCountersUI(); syncDots(); updateSelectedLabel(); updateMiniGridEligibility();
  setInterval(refreshQueue, 1000);
})();
</script>
</body>
</html>
"""

class Handler(BaseHTTPRequestHandler):
    def _set_headers(self, status=200, content_type="text/html"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            self._set_headers(200, "text/html; charset=utf-8")
            self.wfile.write(HTML_PAGE.encode("utf-8"))
            return

        if self.path == "/api/queue/status":
            with queue_lock:
                qcopy = [dict(item) for item in order_queue]
                queued_positions = [it['pos'] for it in order_queue if it['status'] in ('Pending', 'Processing')]
            with order_state_lock:
                emptied_copy = sorted(list(emptied_positions))
            with position_colors_lock:
                selections_copy = dict(position_colors)

            payload = {
                "queue": qcopy,
                "emptied": emptied_copy,
                "running": runner_should_run,
                "queued": sorted(list(set(queued_positions))),
                "selections": selections_copy
            }
            self._set_headers(200, "application/json")
            self.wfile.write(json.dumps(payload).encode("utf-8"))
            return

        if self.path == "/api/diag":
            with logger_refs_lock:
                hbw = logger_refs.get('ESP32_HBW')
                oven = logger_refs.get('ESP32_Oven')
            payload = {
                "HBW_running": bool(hbw and getattr(hbw, "running", False)),
                "Oven_running": bool(oven and getattr(oven, "running", False)),
                "global_dev_zero_ms": global_dev_zero_ms,
                "pending_snapshot_time_ms": pending_snapshot_time_ms,
                "pending_stop_time_ms": pending_stop_time_ms
            }
            self._set_headers(200, "application/json")
            self.wfile.write(json.dumps(payload).encode("utf-8"))
            return

        self._set_headers(404, "text/plain; charset=utf-8")
        self.wfile.write(b"Not Found")

    def do_POST(self):
        global runner_should_run

        def read_json():
            length = int(self.headers.get('Content-Length', '0') or '0')
            body = self.rfile.read(length)
            return json.loads(body.decode('utf-8')) if body else {}

        if self.path == "/api/queue/add":
            try:
                data = read_json()
            except Exception:
                self._set_headers(400, "application/json")
                self.wfile.write(json.dumps({"error": "invalid JSON"}).encode("utf-8"))
                return

            machining = (data.get('machining') or "").strip()
            post_ops = data.get('post_ops') or []
            selections = data.get('selections') or {}
            pos = (data.get('chosen_pos') or "").strip()

            if not pos:
                self._set_headers(400, "application/json")
                self.wfile.write(json.dumps({"error": "chosen_pos required"}).encode("utf-8"))
                return

            include_painting = any(op.lower() == "painting" for op in post_ops)
            include_cleaning = any(op.lower() == "cleaning" for op in post_ops)
            color = selections.get(pos)
            with position_colors_lock:
                for k, v in selections.items():
                    if v in ("white", "red", "blue"):
                        position_colors[k] = v

            with order_state_lock:
                if not color:
                    self._set_headers(400, "application/json")
                    self.wfile.write(json.dumps({"error": "Position has no color"}).encode("utf-8"))
                    return
                if pos in emptied_positions:
                    self._set_headers(400, "application/json")
                    self.wfile.write(json.dumps({"error": "Position already empty"}).encode("utf-8"))
                    return
                if include_painting and str(color).lower() == "white":
                    self._set_headers(400, "application/json")
                    self.wfile.write(json.dumps({"error": "Painting selected → WHITE not allowed"}).encode("utf-8"))
                    return
                if include_cleaning and not include_painting and str(color).lower() != "white":
                    self._set_headers(400, "application/json")
                    self.wfile.write(json.dumps({"error": "Cleaning-only → ONLY WHITE allowed"}).encode("utf-8"))
                    return

            with queue_lock:
                already = any(
                    it['pos'] == pos and it['status'] in ('Pending', 'Processing')
                    for it in order_queue
                )
            if already:
                self._set_headers(400, "application/json")
                self.wfile.write(json.dumps({"error": f"{pos} is already in the queue"}).encode("utf-8"))
                return

            item = {
                "id": str(uuid.uuid4()),
                "pos": pos,
                "color": color,
                "machining": machining,
                "post_ops": list(post_ops),
                "status": "Pending",
                "message": "",
                "ts": now_iso()
            }
            with queue_cv:
                order_queue.append(item)
                queue_cv.notify_all()

            self._set_headers(200, "application/json")
            self.wfile.write(json.dumps({"ok": True, "id": item["id"]}).encode("utf-8"))
            return

        if self.path == "/api/queue/start":
            with queue_cv:
                runner_should_run = True
                queue_cv.notify_all()
            self._set_headers(200, "application/json")
            self.wfile.write(json.dumps({"running": True}).encode("utf-8"))
            return

        if self.path == "/api/queue/stop":
            with queue_cv:
                runner_should_run = False
                queue_cv.notify_all()
            self._set_headers(200, "application/json")
            self.wfile.write(json.dumps({"running": False}).encode("utf-8"))
            return

        if self.path == "/api/queue/clear":
            with queue_lock:
                kept = [it for it in order_queue if it['status'] != 'Pending']
                order_queue.clear()
                order_queue.extend(kept)
            self._set_headers(200, "application/json")
            self.wfile.write(json.dumps({"ok": True}).encode("utf-8"))
            return

        if self.path == "/api/hbw/send":
            try:
                data = read_json()
            except Exception:
                self._set_headers(400, "application/json")
                self.wfile.write(json.dumps({"ok": False, "error": "invalid JSON"}).encode("utf-8"))
                return

            pos = int(str(data.get("pos", 1)))
            with logger_refs_lock:
                hbw = logger_refs.get('ESP32_HBW')

            if (hbw is None) or (not getattr(hbw, "running", False)):
                self._set_headers(500, "application/json")
                self.wfile.write(json.dumps({"ok": False, "error": "HBW serial not open"}).encode("utf-8"))
                return

            ok = hbw.send_line(f"RETRIEVE POS{pos}")
            self._set_headers(200, "application/json")
            self.wfile.write(json.dumps({"ok": bool(ok)}).encode("utf-8"))
            return

        self._set_headers(404, "application/json")
        self.wfile.write(json.dumps({"error": "not found"}).encode("utf-8"))


def start_server():
    server = ThreadingHTTPServer(("127.0.0.1", DASHBOARD_PORT), Handler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    return server


# =======================
# MAIN
# =======================
    
def main():
    writer = CSVWriterThread(OUTPUT_FILE, stop_event)
    writer.start()

    watchdog = WatchdogThread(writer, stop_event)
    watchdog.start()

    start_server()
    try:
        webbrowser.open(f"http://127.0.0.1:{DASHBOARD_PORT}/")
    except Exception:
        pass

    monitors = []
    try:
        for name, cfg in STATIONS.items():
            t = ESP32Logger(
                name=name,
                port=cfg['port'],
                send_command=cfg.get('send_command', False),
                command=cfg.get('command', None),
                trigger_pin=cfg.get('trigger_pin'),
                command_delay_s=cfg.get('command_delay_s', 0.05),
            )
            t.start()
            monitors.append(t)

        if AUTO_LOAD_PRESET:
            load_preset_setup(clear_existing=True, auto_start=False)

        print(f"Dashboard: http://127.0.0.1:{DASHBOARD_PORT}/")
        print(f"Logging started (timeout={SER_TIMEOUT_S*1000:.0f} ms). "
              f"Global t=0 comes from HBW: '{STATIONS['ESP32_HBW']['trigger_pin']}'.")
        print("Stop behavior: after the 9th push on ESP32_ColorSorter (or immediately on STOP flag).")
        print("Extra snapshot: scheduled after the 9th push for every station.")
        print("Queue loaded automatically, but Auto-Run will NOT start until you click Start.")
        print("Rules enforced: Painting blocks WHITE; Cleaning-only requires WHITE.")
        print("Positions already in the queue (Pending/Processing) cannot be added again.")
        print("Press Ctrl+C to stop.")

        if STATIONS.get('ESP32_HBW', {}).get('trigger_pin'):
            t0 = time.perf_counter()
            warned = False
            while global_dev_zero_ms is None and not stop_event.is_set():
                if not warned and (time.perf_counter() - t0) > TRIGGER_WARN_AFTER_S:
                    print(f"WARNING: did not observe HBW trigger '{STATIONS['ESP32_HBW']['trigger_pin']}' "
                          f"within {TRIGGER_WARN_AFTER_S:.1f}s. "
                          f"Alignment will use estimated offsets until trigger appears.")
                    warned = True
                time.sleep(0.01)

        while not stop_event.is_set():
            time.sleep(0.05)

    except KeyboardInterrupt:
        print("\nManual stop requested.")
        stop_event.set()
    finally:
        for t in monitors:
            t.close()
        for t in monitors:
            t.join()

        stop_event.set()
        writer.join()
        watchdog.join()

        with stop_lock:
            if stop_time_global_ms is not None:
                print(f"Final STOP time: {stop_time_global_ms} ms")
            else:
                print("Stopped before scheduled stop was reached.")

        print("All ports closed. Goodbye!")


if __name__ == "__main__":
    main()
