import pandas as pd
import os

def process_experiment_files():
    # 1. Define the input paths
    file_paths = [
        r"C:\Users\anasa\Desktop\Data Collection under work\comp. 1\merged data\Exp 1\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Merged_All_Stations_with_all_parameters.xlsx",
        r"C:\Users\anasa\Desktop\Data Collection under work\comp. 1\merged data\Exp 2\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Merged_All_Stations_with_all_parameters.xlsx",
        r"C:\Users\anasa\Desktop\Data Collection under work\comp. 1\merged data\Exp 3\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Merged_All_Stations_with_all_parameters.xlsx",
        r"C:\Users\anasa\Desktop\Data Collection under work\comp. 1\merged data\Exp 4\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Merged_All_Stations_with_all_parameters.xlsx",
        r"C:\Users\anasa\Desktop\Data Collection under work\comp. 1\merged data\Exp 5\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Merged_All_Stations_with_all_parameters.xlsx",
        r"C:\Users\anasa\Desktop\Data Collection under work\comp. 1\merged data\Exp 6\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Merged_All_Stations_with_all_parameters.xlsx",
        r"C:\Users\anasa\Desktop\Data Collection under work\comp. 1\merged data\Exp 7\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Merged_All_Stations_with_all_parameters.xlsx",
        r"C:\Users\anasa\Desktop\Data Collection under work\comp. 1\merged data\Exp 8\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Merged_All_Stations_with_all_parameters.xlsx",
        r"C:\Users\anasa\Desktop\Data Collection under work\comp. 1\merged data\Exp 9\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Merged_All_Stations_with_all_parameters.xlsx",
        r"C:\Users\anasa\Desktop\Data Collection under work\comp. 1\merged data\Exp 10\piece marking\pices number, HBW pos. grabber, oven order & color sorter\Merged_All_Stations_with_all_parameters.xlsx"
    ]

    match_cols = ['station', 'pin name', 'newstate_norm', 'movement number']

    print("Loading files...")
    all_dfs = []

    for i, path in enumerate(file_paths):
        if os.path.exists(path):
            try:
                df = pd.read_excel(path)
                df.columns = df.columns.str.strip()
                all_dfs.append(df)
                print(f"Loaded Exp {i+1}")
            except Exception as e:
                print(f"Error reading Exp {i+1}: {e}")
        else:
            print(f"File not found: {path}")

    if not all_dfs:
        print("No files loaded. Exiting.")
        return

    # 3. Combine and Calculate Statistics (Added std_rel_time)
    print("Calculating Averages and Standard Deviation...")
    combined_df = pd.concat(all_dfs)

    stats_df = combined_df.groupby(match_cols).agg(
        avg_duration=('duration(ms)', 'mean'),
        std_duration=('duration(ms)', 'std'),
        avg_rel_time=('RelativeTime(ms)', 'mean'),
        std_rel_time=('RelativeTime(ms)', 'std')  # <--- NEW: Added STD for Relative Time
    ).reset_index()

    # 4. Prepare Master Template
    master_df = all_dfs[0].copy()

    # 5. Merge Data
    final_df = pd.merge(master_df, stats_df, on=match_cols, how='left')

    # 6. Update Values
    final_df['duration(ms)'] = final_df['avg_duration']
    final_df['RelativeTime(ms)'] = final_df['avg_rel_time']

    # 7. Organize Output Columns
    cols = list(master_df.columns)
    
    # Rename the merged std columns to friendly names
    final_df = final_df.rename(columns={
        'std_duration': 'duration(ms)_std',
        'std_rel_time': 'RelativeTime(ms)_std' # <--- NEW: Friendly name
    })

    # Insert 'duration(ms)_std' right after 'duration(ms)'
    if 'duration(ms)' in cols:
        cols.insert(cols.index('duration(ms)') + 1, 'duration(ms)_std')
    
    # Insert 'RelativeTime(ms)_std' right after 'RelativeTime(ms)'
    if 'RelativeTime(ms)' in cols:
        cols.insert(cols.index('RelativeTime(ms)') + 1, 'RelativeTime(ms)_std')

    # Final selection of columns
    final_df = final_df[cols]

    # 8. Save Output
    output_dir = r"C:\Users\anasa\Desktop\Data Collection under work"
    output_filename = "Final_Results_with_Avg_and_Std.xlsx"
    output_path = os.path.join(output_dir, output_filename)

    try:
        final_df.to_excel(output_path, index=False)
        print(f"\nSuccess! File saved at:\n{output_path}")
    except Exception as e:
        print(f"Error saving file: {e}")

if __name__ == "__main__":
    process_experiment_files()
